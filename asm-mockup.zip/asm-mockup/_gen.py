# -*- coding: utf-8 -*-
"""ASM 화면 목업 생성기 — 화면 정의를 고쳐 다시 실행하면 전 화면이 갱신됩니다."""
import json, os, random, datetime as dt

ROOT = os.path.expanduser('~/asm-mockup')
random.seed(20260901)

CUST = ['PT Bukit Makmur Mandiri','PT Pamapersada Nusantara','PT Kaltim Prima Coal',
        'PT Saptaindra Sejati','PT Thiess Contractors Indonesia','PT Putra Perkasa Abadi',
        'PT Berau Coal','PT Darma Henwa','PT Cipta Kridatama','PT Ulima Nitra']
REP  = ['Hery','Hanif','Eri','Arif','Rizki']
WH   = ['Cikarang WH','Surabaya WH','Semarang WH','Balikpapan WH','Palembang WH']
SIZE = ['26.5R25','23.5R25','29.5R25','1200R24','1100R20','750-16','825-16','700-12','18.4-34','1000R20']
PATT = ['E3/L3','ETSM','AS-668','AS-108','FL-01','R-1','E4','AS-661','AS-682','E3']
CATG = ['OTR','TB-R','TB-B','IND','AGR']
PAY  = ['CBD','30 Days','45 Days','60 Days','L/C at sight']

def d(off):  return (dt.date(2026,9,1) + dt.timedelta(days=off)).isoformat()

# ── 화면 정의 ──────────────────────────────────────────────────────────
# cols : (key, LABEL, cls, fmt)  cls = '' | num | date | ctr | code | ell
SCREENS = []

def add(**kw): SCREENS.append(kw)

# ══ SALES ══════════════════════════════════════════════════════════════
add(dirn='sales', slug='quotation', menu='Sales', sub='Quotation',
    title='Quotation', desc='Penawaran Harga · 견적서',
    ph='Customer, Quote name, Quote no, Status', new='NEW QUOTATION',
    cols=[('#','#','ctr',None),('no','QUOTE NO.','code',None),('name','QUOTE NAME','ell',None),
          ('pono','PO NO.','code',None),('cust','CUSTOMER','ell',None),
          ('qty','QTY','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('pay','PAYMENT','ctr',None),('eta','EST DELIV. DATE','date',None),
          ('rep','SALES REP','ctr',None),('rmk','REMARK','ell',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty','amt'], totspan=5,
    rows=[dict(no=f'QT-2608-{100+i:03d}', name=f'{random.choice(CATG)} Tire Supply {2026}',
               pono=f'PO-{random.randint(70000,79999)}', cust=random.choice(CUST),
               qty=random.choice([24,48,96,120,240,360,480]),
               amt=random.randint(18000,420000), pay=random.choice(PAY), eta=d(random.randint(7,90)),
               rep=random.choice(REP), rmk=random.choice(['Revisi harga ke-2','Menunggu approval','—','Sample 4 EA','Include delivery']),
               st=random.choice(['DRAFT','PENDING','CONFIRMED','APPROVED','REJECTED','CANCELED']))
          for i in range(24)])

add(dirn='sales', slug='customer-po', menu='Sales', sub='Customer PO',
    title='Customer PO', desc='PO Pelanggan · 고객 발주서 접수·관리',
    ph='Customer, PO no, Quote no, Status', new='NEW CUSTOMER PO',
    cols=[('#','#','ctr',None),('no','PO NO.','code',None),('dt','PO DATE','date',None),
          ('cust','CUSTOMER','ell',None),('qno','QUOTE NO.','code',None),
          ('qty','QTY','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('pay','PAYMENT','ctr',None),('req','REQ DELIV. DATE','date',None),
          ('rep','SALES REP','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty','amt'], totspan=5,
    rows=[dict(no=f'CPO-2608-{200+i:03d}', dt=d(-random.randint(1,60)), cust=random.choice(CUST),
               qno=f'QT-2608-{100+random.randint(0,23):03d}',
               qty=random.choice([24,48,96,144,240,480]), amt=random.randint(15000,380000),
               pay=random.choice(PAY), req=d(random.randint(5,75)), rep=random.choice(REP),
               st=random.choice(['PENDING','CONFIRMED','PARTIAL','COMPLETED','CANCELED']))
          for i in range(21)])

add(dirn='sales', slug='so', menu='Sales', sub='SO',
    title='Sales Order', desc='Pesanan Penjualan · 수주',
    ph='Customer, SO no, PO no, Status', new='NEW SO',
    cols=[('#','#','ctr',None),('no','SO NO.','code',None),('dt','SO DATE','date',None),
          ('cust','CUSTOMER','ell',None),('pono','PO NO.','code',None),
          ('qty','ORDER QTY','num','ASM.fmt.int'),('dlv','DELIVERED','num','ASM.fmt.int'),
          ('bal','BALANCE','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('wh','WAREHOUSE','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty','dlv','bal','amt'], totspan=5,
    rows=[(lambda q,dl: dict(no=f'SO-2608-{300+i:03d}', dt=d(-random.randint(1,50)),
               cust=random.choice(CUST), pono=f'CPO-2608-{200+random.randint(0,20):03d}',
               qty=q, dlv=dl, bal=q-dl, amt=random.randint(12000,300000), wh=random.choice(WH),
               st='COMPLETED' if q==dl else ('PARTIAL' if dl>0 else 'OPEN')))(
           *(lambda q: (q, random.choice([0, q//2, q])))(random.choice([48,96,144,240,360])))
          for i in range(19)])

add(dirn='sales', slug='delivery-order', menu='Sales', sub='Delivery Order',
    title='Delivery Order', desc='Surat Jalan (DO) · 출하지시서',
    ph='Customer, DO no, SO no, Vehicle no', new='NEW DO',
    cols=[('#','#','ctr',None),('no','DO NO.','code',None),('dt','DO DATE','date',None),
          ('sono','SO NO.','code',None),('cust','CUSTOMER','ell',None),
          ('wh','WAREHOUSE','ctr',None),('qty','QTY','num','ASM.fmt.int'),
          ('drv','DRIVER','ctr',None),('veh','VEHICLE NO.','code',None),
          ('eta','EST ARRIVAL','date',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty'], totspan=6,
    rows=[dict(no=f'DO-2608-{400+i:03d}', dt=d(-random.randint(0,30)),
               sono=f'SO-2608-{300+random.randint(0,18):03d}', cust=random.choice(CUST),
               wh=random.choice(WH), qty=random.choice([12,24,36,48,96,120]),
               drv=random.choice(['Budi','Agus','Slamet','Wayan','Joko']),
               veh=random.choice(['B 9123 UYZ','L 8871 KP','H 4420 ND','KT 7712 AL','BG 3390 QN']),
               eta=d(random.randint(0,14)),
               st=random.choice(['ISSUED','IN TRANSIT','DELIVERED','PENDING','CANCELED']))
          for i in range(18)])

add(dirn='sales', slug='delivery-note', menu='Sales', sub='Delivery Note',
    title='Delivery Note', desc='Bukti Terima Barang · 납품확인서',
    ph='Customer, DN no, DO no, Received by', new='NEW DN',
    cols=[('#','#','ctr',None),('no','DN NO.','code',None),('dt','DN DATE','date',None),
          ('dono','DO NO.','code',None),('cust','CUSTOMER','ell',None),
          ('qty','QTY','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('rcv','RECEIVED BY','ctr',None),('rdt','RECEIVED DATE','date',None),
          ('st','STATUS','ctr','ASM.badge')],
    total=['qty','amt'], totspan=5,
    rows=[dict(no=f'DN-2608-{500+i:03d}', dt=d(-random.randint(0,28)),
               dono=f'DO-2608-{400+random.randint(0,17):03d}', cust=random.choice(CUST),
               qty=random.choice([12,24,36,48,96]), amt=random.randint(8000,160000),
               rcv=random.choice(['Sdr. Iwan','Sdr. Nanang','Sdri. Rina','Sdr. Bagus','Sdr. Hendra']),
               rdt=d(-random.randint(0,25)),
               st=random.choice(['RECEIVED','PENDING','PARTIAL','DELIVERED']))
          for i in range(17)])

# ══ INVENTORY ══════════════════════════════════════════════════════════
add(dirn='inventory', slug='stock-movement', menu='Inventory', sub='Stock Movement',
    title='Stock Movement', desc='Mutasi Stok · 재고 입출고 내역',
    ph='Doc no, Item code, Size, Warehouse', new=None,
    cols=[('#','#','ctr',None),('dt','DATE','date',None),('doc','DOC NO.','code',None),
          ('typ','TYPE','ctr','ASM.badge'),('wh','WAREHOUSE','ctr',None),
          ('code','ITEM CODE','code',None),('size','SIZE','',None),('patt','PATTERN','',None),
          ('inq','IN','num','ASM.fmt.int'),('outq','OUT','num','ASM.fmt.int'),
          ('bal','BALANCE','num','ASM.fmt.int'),('rmk','REMARK','ell',None)],
    total=['inq','outq'], totspan=8,
    rows=[(lambda t: dict(dt=d(-random.randint(0,45)),
               doc=f'{"RC" if t=="RECEIVED" else "DN"}-2608-{600+i:03d}', typ=t,
               wh=random.choice(WH), code=f'{random.choice(CATG)}-{random.randint(1000,9999)}',
               size=random.choice(SIZE), patt=random.choice(PATT),
               inq=random.choice([0,24,48,120,240]) if t=='RECEIVED' else 0,
               outq=0 if t=='RECEIVED' else random.choice([12,24,36,48]),
               bal=random.randint(20,900),
               rmk=random.choice(['Import container','Penjualan','Transfer masuk','Adjustment','—'])))(
           random.choice(['RECEIVED','DELIVERED','POSTED']))
          for i in range(26)])

add(dirn='inventory', slug='stock-adjustment', menu='Inventory', sub='Stock Adjustment',
    title='Stock Adjustment', desc='Penyesuaian Stok · 재고 조정',
    ph='Adj no, Item code, Warehouse, Reason', new='NEW ADJUSTMENT',
    cols=[('#','#','ctr',None),('no','ADJ NO.','code',None),('dt','ADJ DATE','date',None),
          ('wh','WAREHOUSE','ctr',None),('code','ITEM CODE','code',None),('size','SIZE','',None),
          ('sys','SYSTEM QTY','num','ASM.fmt.int'),('act','ACTUAL QTY','num','ASM.fmt.int'),
          ('dif','DIFF','num','v=>(v>0?"+":"")+ASM.fmt.int(v)'),
          ('rsn','REASON','ell',None),('req','REQUESTED BY','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['sys','act','dif'], totspan=6,
    rows=[(lambda s,a: dict(no=f'ADJ-2608-{700+i:03d}', dt=d(-random.randint(0,40)),
               wh=random.choice(WH), code=f'{random.choice(CATG)}-{random.randint(1000,9999)}',
               size=random.choice(SIZE), sys=s, act=a, dif=a-s,
               rsn=random.choice(['Selisih hitung fisik','Barang rusak (defect)','Salah input DO',
                                  'Retur pelanggan','Temuan stock opname']),
               req=random.choice(['Firman','Komang','Rizki','Hery']),
               st=random.choice(['DRAFT','PENDING','APPROVED','REJECTED','POSTED'])))(
           *(lambda s: (s, s + random.choice([-8,-4,-2,-1,1,2,5])))(random.randint(20,400)))
          for i in range(16)])

add(dirn='inventory', slug='stock-transfer', menu='Inventory', sub='Stock Transfer',
    title='Stock Transfer', desc='Transfer Antar Gudang · 창고 간 이고',
    ph='Trf no, Item code, From WH, To WH', new='NEW TRANSFER',
    cols=[('#','#','ctr',None),('no','TRF NO.','code',None),('dt','TRF DATE','date',None),
          ('fwh','FROM WH','ctr',None),('twh','TO WH','ctr',None),
          ('code','ITEM CODE','code',None),('size','SIZE','',None),
          ('qty','QTY','num','ASM.fmt.int'),('veh','VEHICLE NO.','code',None),
          ('eta','EST ARRIVAL','date',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty'], totspan=7,
    rows=[(lambda f: dict(no=f'TRF-2608-{800+i:03d}', dt=d(-random.randint(0,35)), fwh=f,
               twh=random.choice([w for w in WH if w != f]),
               code=f'{random.choice(CATG)}-{random.randint(1000,9999)}', size=random.choice(SIZE),
               qty=random.choice([12,24,48,60,120]),
               veh=random.choice(['B 9123 UYZ','L 8871 KP','H 4420 ND','KT 7712 AL']),
               eta=d(random.randint(0,12)),
               st=random.choice(['ISSUED','IN TRANSIT','RECEIVED','PENDING','CANCELED'])))(random.choice(WH))
          for i in range(15)])

add(dirn='inventory', slug='stock-opname', menu='Inventory', sub='Stock Opname',
    title='Stock Opname', desc='Perhitungan Fisik Stok · 재고 실사',
    ph='Opname no, Warehouse, Period, PIC', new='NEW OPNAME',
    cols=[('#','#','ctr',None),('no','OPNAME NO.','code',None),('prd','PERIOD','ctr',None),
          ('wh','WAREHOUSE','ctr',None),('tsku','TOTAL SKU','num','ASM.fmt.int'),
          ('csku','COUNTED','num','ASM.fmt.int'),('dsku','DIFF SKU','num','ASM.fmt.int'),
          ('dqty','DIFF QTY','num','v=>(v>0?"+":"")+ASM.fmt.int(v)'),
          ('dval','DIFF VALUE','num','v=>ASM.fmt.cur("USD",v)'),
          ('rate','PROGRESS','num','ASM.fmt.pct'),
          ('pic','PIC','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['tsku','csku','dsku','dqty','dval'], totspan=4,
    rows=[(lambda t,c: dict(no=f'OPN-26{m:02d}-{900+i:03d}', prd=f'2026-{m:02d}',
               wh=random.choice(WH), tsku=t, csku=c, dsku=random.randint(0,9),
               dqty=random.choice([-14,-6,-2,0,3,8]), dval=random.randint(-4200,3800),
               rate=round(c/t*100,1),
               pic=random.choice(['Firman','Komang','Hery','Hanif']),
               st='COMPLETED' if c==t else ('PENDING' if c>0 else 'DRAFT')))(
           *(lambda t: (t, random.choice([t, t, int(t*0.6), 0])))(random.randint(120,480)))
          for i,m in enumerate([4,5,5,6,6,7,7,8,8,8,9,9])])

# ══ MASTER DATA ════════════════════════════════════════════════════════
add(dirn='master', slug='item', menu='Master Data', sub='Item',
    title='Item Master', desc='Master Barang · 품목 마스터',
    ph='Item code, Size, Pattern, Brand', new='NEW ITEM',
    cols=[('#','#','ctr',None),('code','ITEM CODE','code',None),('cat','CATEGORY','ctr',None),
          ('brand','BRAND','',None),('size','SIZE','',None),('patt','PATTERN','',None),
          ('pr','PR / TL','ctr',None),('wt','WEIGHT','num','ASM.fmt.kg'),
          ('hs','HS CODE','code',None),('uom','UOM','ctr',None),
          ('cost','STD COST (USD)','num','ASM.fmt.price'),('st','STATUS','ctr','ASM.badge')],
    total=None, totspan=1,
    rows=[dict(code=f'{random.choice(CATG)}-{random.randint(1000,9999)}', cat=random.choice(CATG),
               brand=random.choice(['Ascendo','Techking','Solideal','Arami']),
               size=random.choice(SIZE), patt=random.choice(PATT),
               pr=random.choice(['**','12PR','14PR','16PR','18PR','20PR','40PR','—']),
               wt=round(random.uniform(18,412),1),
               hs=random.choice(['4011.80.00','4011.20.10','4011.70.00','4011.90.00']),
               uom='EA', cost=round(random.uniform(58,2380),2),
               st=random.choice(['ACTIVE','ACTIVE','ACTIVE','INACTIVE']))
          for i in range(28)])

add(dirn='master', slug='brand-pattern', menu='Master Data', sub='Brand / Pattern',
    title='Brand / Pattern', desc='Merek & Pola Tapak · 브랜드·패턴 마스터',
    ph='Brand, Pattern, Category, Factory', new='NEW PATTERN',
    cols=[('#','#','ctr',None),('brand','BRAND','',None),('patt','PATTERN','code',None),
          ('cat','CATEGORY','ctr',None),('app','APPLICATION','ell',None),
          ('org','ORIGIN','ctr',None),('fac','FACTORY','ell',None),
          ('cnt','ITEM COUNT','num','ASM.fmt.int'),('st','STATUS','ctr','ASM.badge')],
    total=['cnt'], totspan=7,
    rows=[dict(brand=b, patt=p, cat=c, app=a, org=o, fac=f, cnt=random.randint(3,46),
               st=random.choice(['ACTIVE','ACTIVE','INACTIVE']))
          for b,p,c,a,o,f in [
            ('Ascendo','AS-668','TB-R','Long haul / on-road','China','Dongying Rungold Tyre'),
            ('Ascendo','AS-682','TB-R','Mixed service / on-off road','China','Dongying Rungold Tyre'),
            ('Ascendo','AS-661','TB-R','Regional distribution','China','Dongying Rungold Tyre'),
            ('Ascendo','AS-108','TB-B','Light truck bias','Indonesia','PT Arami Jaya'),
            ('Ascendo','E3/L3','OTR','Loader / dump truck','China','Techking OEM'),
            ('Ascendo','E4','OTR','Rigid dump truck (deep tread)','China','Techking OEM'),
            ('Ascendo','FL-01','IND','Forklift pneumatic','Indonesia','PT Arami Jaya'),
            ('Ascendo','R-1','AGR','Tractor rear','China','Dongying Rungold Tyre'),
            ('Techking','ETSM','OTR','Mining haul / scraper','China','Techking Tires'),
            ('Solideal','SOLID','IND','Forklift solid / press-on','Sri Lanka','Camso Loadstar'),
            ('Arami','ARM-TB','TB-B','Bias truck local','Indonesia','PT Arami Jaya'),
            ('Arami','ARM-IT','IND','Inner tube (ban dalam)','Indonesia','PT Arami Jaya')]])

add(dirn='master', slug='warehouse', menu='Master Data', sub='Warehouse',
    title='Warehouse', desc='Gudang · 창고 마스터',
    ph='WH code, Warehouse name, City, PIC', new='NEW WAREHOUSE',
    cols=[('#','#','ctr',None),('code','WH CODE','code',None),('nm','WAREHOUSE NAME','ell',None),
          ('typ','TYPE','ctr',None),('city','CITY','',None),('addr','ADDRESS','ell',None),
          ('pic','PIC','ctr',None),('cap','CAPACITY (EA)','num','ASM.fmt.int'),
          ('cur','CURRENT (EA)','num','ASM.fmt.int'),('util','UTIL.','num','ASM.fmt.pct'),
          ('st','STATUS','ctr','ASM.badge')],
    total=['cap','cur'], totspan=7,
    rows=[(lambda cap,cur: dict(code=c, nm=n, typ=t, city=ct, addr=ad, pic=p,
               cap=cap, cur=cur, util=round(cur/cap*100,1),
               st='ACTIVE' if act else 'INACTIVE'))(cp,cr)
          for c,n,t,ct,ad,p,cp,cr,act in [
            ('WH-CKR','Cikarang Main Warehouse','Main','Cikarang','Jl. Jababeka Raya Blok F, Kawasan Industri','Firman',12000,8420,True),
            ('WH-SBY','Surabaya Branch Warehouse','Branch','Surabaya','Jl. Margomulyo Indah No. 12','Hery',6000,4130,True),
            ('WH-SMG','Semarang Branch Warehouse','Branch','Semarang','Jl. Raya Kaligawe KM 5','Hanif',4500,2680,True),
            ('WH-BPP','Balikpapan Branch Warehouse','Branch','Balikpapan','Jl. Mulawarman No. 88, Manggar','Arif',3500,1940,True),
            ('WH-PLB','Palembang Branch Warehouse','Branch','Palembang','Jl. Soekarno Hatta KM 9','Rizki',3000,860,True),
            ('WH-TRN','Transit / In-Transit Stock','Transit','—','Dalam perjalanan antar gudang','—',2000,320,True),
            ('WH-QAR','Quarantine / Defect Area','Quarantine','Cikarang','Jl. Jababeka Raya Blok F (Zona B)','Firman',800,214,True),
            ('WH-OLD','Jakarta Old Warehouse','Branch','Jakarta','Jl. Daan Mogot KM 12','—',2500,0,False)]])

# ══ SETTINGS ═══════════════════════════════════════════════════════════
add(dirn='master', slug='user', menu='Settings', sub='User',
    title='User', desc='Pengguna · 사용자 계정 관리',
    ph='User ID, Name, Department, Role', new='NEW USER',
    cols=[('#','#','ctr',None),('uid','USER ID','code',None),('nm','NAME','',None),
          ('dept','DEPARTMENT','',None),('pos','POSITION','ell',None),
          ('mail','EMAIL','ell',None),('role','ROLE','ctr',None),
          ('last','LAST LOGIN','date',None),('st','STATUS','ctr','ASM.badge')],
    total=None, totspan=1,
    rows=[dict(uid=u, nm=n, dept=dp, pos=ps, mail=f'{u}@ascendotyre.com', role=r,
               last=d(-random.randint(0,20)), st=s)
          for u,n,dp,ps,r,s in [
            ('seo','Seo Hunga','Management','General Manager','ADMIN','ACTIVE'),
            ('hery','Hery','Sales','Sales Rep — Surabaya','SALES','ACTIVE'),
            ('hanif','Hanif','Sales','Sales Rep — Central/East Java','SALES','ACTIVE'),
            ('eri','Eri','Sales','Sales Rep — Jakarta','SALES','ACTIVE'),
            ('arif','Arif','Sales','Sales Rep — West Kalimantan','SALES','ACTIVE'),
            ('rizki','Rizki','Sales','Field Team','SALES','ACTIVE'),
            ('firman','Firman','Warehouse','Warehouse Staff','WAREHOUSE','ACTIVE'),
            ('komang','Komang','Finance','Finance Staff','FINANCE','ACTIVE'),
            ('purch01','Andi Pratama','Purchasing','Import Staff','PURCHASING','ACTIVE'),
            ('acc01','Sri Wahyuni','Finance','Accounting Staff','FINANCE','ACTIVE'),
            ('audit01','External Auditor','—','Read-only Access','VIEWER','INACTIVE')]])

add(dirn='master', slug='role-permission', menu='Settings', sub='Role / Permission',
    title='Role / Permission', desc='Peran & Hak Akses · 권한 매트릭스',
    ph='Role code, Role name, Module', new='NEW ROLE',
    cols=[('#','#','ctr',None),('rc','ROLE CODE','code',None),('rn','ROLE NAME','ell',None),
          ('mod','MODULE','',None),('v','VIEW','ctr','ASM.mark'),('c','CREATE','ctr','ASM.mark'),
          ('e','EDIT','ctr','ASM.mark'),('dl','DELETE','ctr','ASM.mark'),
          ('ap','APPROVE','ctr','ASM.mark'),('ex','EXPORT','ctr','ASM.mark'),
          ('cnt','USERS','num','ASM.fmt.int')],
    total=None, totspan=1,
    rows=[dict(rc=rc, rn=rn, mod=m, v=v, c=c, e=e, dl=dl, ap=ap, ex=ex, cnt=n)
          for rc,rn,m,v,c,e,dl,ap,ex,n in [
            ('ADMIN','System Administrator','All Modules',1,1,1,1,1,1,1),
            ('SALES','Sales Representative','Sales',1,1,1,0,0,1,5),
            ('SALES','Sales Representative','Inventory',1,0,0,0,0,0,5),
            ('SALES','Sales Representative','Partners',1,1,1,0,0,0,5),
            ('PURCHASING','Purchasing / Import Staff','Purchasing',1,1,1,0,0,1,1),
            ('PURCHASING','Purchasing / Import Staff','Inventory',1,0,0,0,0,1,1),
            ('WAREHOUSE','Warehouse Staff','Inventory',1,1,1,0,0,1,1),
            ('WAREHOUSE','Warehouse Staff','Sales',1,0,1,0,0,0,1),
            ('FINANCE','Finance / Accounting','Sales',1,0,0,0,1,1,2),
            ('FINANCE','Finance / Accounting','Purchasing',1,0,0,0,1,1,2),
            ('MANAGER','Department Manager','All Modules',1,1,1,0,1,1,0),
            ('VIEWER','Read-only / Auditor','All Modules',1,0,0,0,0,1,1)]])

add(dirn='master', slug='approval-matrix', menu='Settings', sub='Approval Matrix',
    title='Approval Matrix', desc='Matriks Persetujuan · 승인 매트릭스',
    ph='Doc type, Approver, Status', new='NEW RULE',
    cols=[('#','#','ctr',None),('doc','DOC TYPE','ell',None),
          ('lim','AMOUNT LIMIT','num','v=>v?ASM.fmt.cur("USD",v):"무제한"'),
          ('s1','STEP 1','ctr',None),('s2','STEP 2','ctr',None),('s3','STEP 3','ctr',None),
          ('sod','SoD RULE','ell',None),('eff','EFFECTIVE DATE','date',None),
          ('st','STATUS','ctr','ASM.badge')],
    total=None, totspan=1,
    rows=[dict(doc=dc, lim=lm, s1=a1, s2=a2, s3=a3, sod=sd, eff=ef, st=st)
          for dc,lm,a1,a2,a3,sd,ef,st in [
            ('Quotation', 50000,'Sales Rep','Sales Manager','—','기안자 승인 불가','2026-01-01','ACTIVE'),
            ('Quotation', 0,'Sales Rep','Sales Manager','General Manager','기안자 승인 불가','2026-01-01','ACTIVE'),
            ('Customer PO', 100000,'Sales Manager','Finance','—','여신한도 초과 시 Finance 필수','2026-01-01','ACTIVE'),
            ('Sales Order', 0,'Sales Manager','Finance','General Manager','재고 미확보 시 반려','2026-01-01','ACTIVE'),
            ('Delivery Order', 0,'Warehouse Staff','Warehouse Manager','—','출고자·승인자 분리','2026-03-01','ACTIVE'),
            ('Purchase PO', 200000,'Purchasing Staff','Purchasing Manager','—','발주자 승인 불가','2026-01-01','ACTIVE'),
            ('Purchase PO', 0,'Purchasing Staff','Purchasing Manager','General Manager','발주자 승인 불가','2026-01-01','ACTIVE'),
            ('Stock Adjustment', 5000,'Warehouse Staff','Warehouse Manager','—','실사자·승인자 분리','2026-03-01','ACTIVE'),
            ('Stock Adjustment', 0,'Warehouse Staff','Warehouse Manager','General Manager','실사자·승인자 분리','2026-03-01','ACTIVE'),
            ('Stock Transfer', 0,'Warehouse Staff','Warehouse Manager','—','출고창고·입고창고 각각 확인','2026-03-01','ACTIVE'),
            ('Credit Note', 0,'Finance','Finance Manager','General Manager','발행자 승인 불가','2026-05-01','ACTIVE'),
            ('Master Data 변경', 0,'해당 부서','System Administrator','—','데이터 오너 승인 필수','2026-06-01','PENDING')]])

# ── HTML 생성 ──────────────────────────────────────────────────────────
def js_cols(cols):
    out = []
    for k, lab, cls, f in cols:
        s = '{key:%s,label:%s' % (json.dumps(k), json.dumps(lab))
        if cls: s += ',cls:%s' % json.dumps(cls)
        if f:   s += ',fmt:' + f
        out.append(s + '}')
    return ',\n      '.join(out)

PAGE = '''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="PT ASCENDO INTERNASIONAL">
<title>{title} · ASM</title>
<link rel="stylesheet" href="../assets/asm-common.css">
</head>
<body data-menu="{menu}" data-sub="{sub}">

<main class="asm-main">

  <div class="mock-flag">
    시안(Mock-up)입니다 — 실제 ASM 데이터가 아니며 표시된 수치는 모두 예시입니다.
    디자인 기준 : ASM 디자인가이드 v1.0 (삼탄 TMS). 배포 시 이 줄과 <code>.mock-flag</code> 를 삭제하십시오.
  </div>

  <div class="page-head">
    <div>
      <h1>{title}</h1>
      <div class="desc">{desc}</div>
    </div>
    <div class="right">
      <button class="btn btn-outline" onclick="window.print()">Print</button>
      <button class="btn btn-outline" data-csv>Excel</button>
      {newbtn}
    </div>
  </div>

  <!-- 검색 바 -->
  <div class="search-bar">
    <span class="sb-label">Search</span>
    <select class="form-select">
      <option>Keyword</option>{opts}
    </select>
    <input class="form-control" type="search" data-search placeholder="{ph}">
    <button class="btn btn-primary" data-search-btn>SEARCH</button>
    <button class="btn btn-outline" data-reset>RESET</button>
  </div>

  <!-- 목록 -->
  <div class="card">
    <div class="card-head">
      <h2>{title} List</h2>
      <span class="count-badge" data-count>0</span>
      <span class="spacer"></span>
      <span class="meta" data-pageinfo>Page 1 of 1</span>
    </div>
    <div id="grid"></div>
  </div>

</main>

<script src="../assets/asm-common.js"></script>
<script>
/* 이 화면의 데이터 — 실서비스 연결 시 fetch('/api/{slug}') 결과로 교체하십시오. */
const ROWS = {rows};

ASM.grid({{
  mount   : '#grid',
  pageSize: 15,
  columns : [
      {cols}
  ],{total}
  rows    : ROWS
}});
</script>
</body>
</html>
'''

INDEX_ROWS = []
for s in SCREENS:
    opts = ''.join('<option>%s</option>' % lab for k, lab, c, f in s['cols'] if k != '#')
    newbtn = ('<button class="btn btn-primary">＋ %s</button>' % s['new']) if s['new'] else ''
    total = ('\n  total   : %s,\n  totalLabelSpan : %d,' % (json.dumps(s['total']), s['totspan'])) if s['total'] else ''
    html = PAGE.format(title=s['title'], menu=s['menu'], sub=s['sub'], desc=s['desc'],
                       ph=s['ph'], opts=opts, newbtn=newbtn, slug=s['slug'],
                       rows=json.dumps(s['rows'], ensure_ascii=False, indent=0).replace('\n', ''),
                       cols=js_cols(s['cols']), total=total)
    path = os.path.join(ROOT, s['dirn'], s['slug'] + '.html')
    open(path, 'w', encoding='utf-8').write(html)
    INDEX_ROWS.append((s['menu'], s['sub'], s['dirn'] + '/' + s['slug'] + '.html', s['desc'], len(s['rows'])))

print('generated', len(SCREENS), 'screens')
open(os.path.join(ROOT, '_index_rows.json'), 'w', encoding='utf-8').write(
    json.dumps(INDEX_ROWS, ensure_ascii=False))
