/* ==========================================================================
   ASM 공통 스크립트  ·  asm-common.js
   PT ASCENDO INTERNASIONAL

   역할 3가지
     1) 헤더·사이드바·푸터를 MENU 정의로부터 자동 생성 (화면마다 복사 불필요)
     2) 사내 숫자 표기 규칙 포맷터 (ASM.fmt)
     3) 표 렌더링 · 검색 · 정렬 · 페이지네이션 공통 로직 (ASM.grid)

   화면 HTML 에서는 아래 두 줄만 선언하면 됩니다.
     <body data-menu="Sales" data-sub="Quotation">
     ASM.grid({ mount:'#grid', columns:[...], rows:[...] })
   ========================================================================== */
(function (global) {
'use strict';

/* ── 1. 메뉴 정의 ── 메뉴를 바꾸려면 여기만 수정하십시오 ─────────────── */
const MENU = [
  /* 슬러그는 실제 ASM 라우트와 동일하게 맞췄습니다 (2026-09-01 실측).
     예) Purchase PO = /vendor-po, Receipt = /receipts, Receipt(WH) = /receipts-wh */
  { name:'Purchasing', base:'purchasing', items:[
      ['Purchase PO','vendor-po'], ['PPC','ppc'], ['Shipment','shipment'],
      ['Customs','customs'], ['Receipt','receipts'], ['Receipt(WH)','receipts-wh'],
      ['Import Cost','import-cost'], ['Vendor Return','vendor-return'], ['Credit Note','credit-note'] ]},
  { name:'Sales', base:'sales', items:[
      ['Quotation','quotation'], ['Customer PO','customer-po'], ['SO','so'],
      ['Delivery Order','delivery-order'], ['Delivery Note','delivery-note'],
      ['Delivery Note (WH)','delivery-note-wh'] ]},
  { name:'Inventory', base:'inventory', items:[
      ['Inventory List','inventory-list'], ['Stock Movement','stock-movement'],
      ['Stock Adjustment','stock-adjustment'], ['Stock Transfer','stock-transfer'],
      ['Stock Opname','stock-opname'] ]},
  /* 실제 ASM Partners 는 2개뿐입니다 (Forwarder 메뉴는 존재하지 않음) */
  { name:'Partners', base:'partners', items:[
      ['Customers','customer'], ['Suppliers','vendor'] ]},
  { name:'Master Data', base:'master', items:[
      ['Item','item'], ['Brand / Pattern','brand-pattern'],
      ['Warehouse','warehouse'], ['Currency','currency'] ]},
  { name:'Settings', base:'master', items:[
      ['User','user'], ['Role / Permission','role-permission'],
      ['Approval Matrix','approval-matrix'] ]}
];

const USER = { name:'Seo', initials:'SH', role:'General Manager' };

/* ── 2. 숫자 표기 (사내 표준 · 가이드 8-3) ───────────────────────────── */
const fmt = {
  /* 수량·정수 : 천 단위 콤마, 소수 없음        1,250,000 */
  int  : n => Number(n).toLocaleString('en-US', {maximumFractionDigits:0}),
  /* 단가 : 소수점 둘째 자리 고정               84.25 */
  price: n => Number(n).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}),
  /* 퍼센트 : 소수점 첫째 자리 고정             12.5% / 3.0% */
  pct  : n => Number(n).toLocaleString('en-US', {minimumFractionDigits:1, maximumFractionDigits:1}) + '%',
  /* 중량 : 소수점 첫째 자리                    62.5 kg */
  kg   : n => Number(n).toLocaleString('en-US', {minimumFractionDigits:1, maximumFractionDigits:1}) + ' kg',
  /* 통화 : 통화코드 + 정수                     IDR 756,704,706 */
  cur  : (c,n) => c + ' ' + Number(n).toLocaleString('en-US', {maximumFractionDigits:0}),
  /* IDR 대금액 병기 : 전체 자리수 먼저, 단위 괄호 병기 (대외문서 필수)
     IDR 1,250,000,000 (1.25 miliar) */
  idr  : n => {
    const v = Number(n), f = x => x.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    let unit = '';
    if (v >= 1e12)      unit = f(v/1e12) + ' triliun';
    else if (v >= 1e9)  unit = f(v/1e9)  + ' miliar';
    else if (v >= 1e6)  unit = f(v/1e6)  + ' juta';
    const full = 'IDR ' + v.toLocaleString('en-US',{maximumFractionDigits:0});
    return unit ? full + ' (' + unit + ')' : full;
  },
  /* 날짜 : YYYY-MM-DD 고정 */
  date : d => (d instanceof Date ? d : new Date(d)).toISOString().slice(0,10)
};

/* ── 3. 상태 배지 ────────────────────────────────────────────────────── */
const BADGE = {                       /* 가이드 3-2 상태 색상 매핑 */
  DRAFT:'neutral', PENDING:'warning', DELAYED:'warning', OPEN:'warning',
  CONFIRMED:'info', APPROVED:'info', ISSUED:'info', PARTIAL:'info', 'IN TRANSIT':'info',
  COMPLETED:'success', RECEIVED:'success', DELIVERED:'success', CLOSED:'success', ACTIVE:'success', POSTED:'success',
  CANCELED:'danger', REJECTED:'danger', INACTIVE:'danger', OVERDUE:'danger'
};
const badge = s => `<span class="asm-badge asm-badge--${BADGE[s] || 'neutral'}">${s}</span>`;

/* 권한 표 등 O/X 표시 : 1 = 허용, 0 = 불허 */
const mark = v => (Number(v)
  ? '<span style="color:var(--asm-success-fg);font-weight:700">\u2713</span>'
  : '<span style="color:var(--asm-border)">\u2014</span>');

/* ── 4. 화면 골격 생성 ───────────────────────────────────────────────── */
function buildShell(){
  const cur = document.body.dataset.menu || '';
  const sub = document.body.dataset.sub  || '';
  const grp = MENU.find(m => m.name === cur) || MENU[0];
  const up  = location.pathname.includes('/sales/') || location.pathname.includes('/inventory/')
           || location.pathname.includes('/master/') || location.pathname.includes('/purchasing/')
           || location.pathname.includes('/partners/') ? '../' : '';

  const nav = MENU.map(m =>
    `<a href="${up}${m.base}/${m.items[0][1]}.html" class="${m.name===cur?'active':''}">${m.name}</a>`).join('');

  const side = MENU.filter(m => m.name===cur).map(m =>
    `<div class="grp">${m.name}</div>` +
    m.items.map(([label,slug]) =>
      `<a class="sub-item ${label===sub?'active':''}" href="${up}${m.base}/${slug}.html">${label}</a>`).join('')
  ).join('');

  document.body.insertAdjacentHTML('afterbegin',
    `<div class="asm-accent-bar"></div>
     <header class="menu-header">
       <a class="brand" href="${up}index.html"><span class="mark">A</span><b>ASM</b></a>
       <nav>${nav}</nav>
       <div class="spacer"></div>
       <div class="hdr-tools">
         <button class="lang" type="button">EN</button>
         <div class="user"><span class="ava">${USER.initials}</span><span class="nm">${USER.name}</span></div>
       </div>
     </header>`);

  const wrap = document.createElement('div');
  wrap.className = 'asm-body';
  wrap.innerHTML = side ? `<aside class="sidebar">${side}</aside>` : '';
  const main = document.querySelector('.asm-main');
  document.body.insertBefore(wrap, main);
  wrap.appendChild(main);

  document.body.insertAdjacentHTML('beforeend',
    `<footer class="asm-footer">
       <span>PT ASCENDO INTERNASIONAL · ASM</span><div class="spacer"></div>
       <span>디자인 기준 : ASM 디자인가이드 v1.0 (삼탄 TMS)</span>
     </footer>`);
}

/* ── 5. 표 공통 렌더러 ───────────────────────────────────────────────── */
/*  columns : [{key,label,cls,fmt,width}]  cls = 'num' | 'date' | 'ctr' | 'code' | 'ell'
    rows    : 객체 배열
    total   : 합계를 낼 key 배열 (선택)                                     */
function grid(cfg){
  const host = document.querySelector(cfg.mount);
  const cols = cfg.columns, all = cfg.rows.slice();
  let view = all.slice(), page = 1, size = cfg.pageSize || 15, sortKey = null, sortDir = 1;

  host.innerHTML =
    `<div class="table-wrap"><table class="asm-table">
       <thead><tr>${cols.map(c =>
         `<th class="${c.cls||''}" data-key="${c.key}" style="${c.width?'width:'+c.width:''}">${c.label}</th>`).join('')}</tr></thead>
       <tbody></tbody>
       ${cfg.total ? `<tfoot><tr></tr></tfoot>` : ''}
     </table></div>
     <div class="pager"><span class="p-info"></span><span class="spacer"></span><span class="pages"></span></div>`;

  const tbody = host.querySelector('tbody');
  const tfootRow = host.querySelector('tfoot tr');

  function cell(r, c){
    const raw = r[c.key];
    const val = c.fmt ? c.fmt(raw, r) : (raw === undefined || raw === null || raw === '' ? '—' : raw);
    return `<td class="${c.cls||''}"${c.cls==='ell'?` title="${String(raw??'')}"`:''}>${val}</td>`;
  }

  function render(){
    const pages = Math.max(1, Math.ceil(view.length / size));
    page = Math.min(page, pages);
    const st = (page-1)*size, rows = view.slice(st, st+size);

    tbody.innerHTML = rows.length
      ? rows.map((r,i) => `<tr class="is-clickable">${cols.map(c =>
          c.key === '#' ? `<td class="ctr">${st+i+1}</td>` : cell(r,c)).join('')}</tr>`).join('')
      : `<tr class="empty-row"><td colspan="${cols.length}">조회된 데이터가 없습니다.</td></tr>`;

    if (tfootRow){
      tfootRow.innerHTML = cols.map((c,i) => {
        if (i === 0) return `<td colspan="${cfg.totalLabelSpan||1}">합계 / Total</td>`;
        if (i < (cfg.totalLabelSpan||1)) return '';
        if (cfg.total.includes(c.key)){
          const s = view.reduce((a,r) => a + (Number(r[c.key])||0), 0);
          return `<td class="num">${c.fmt ? c.fmt(s) : fmt.int(s)}</td>`;
        }
        return `<td class="${c.cls||''}"></td>`;
      }).join('');
    }

    host.querySelector('.p-info').textContent = view.length
      ? `${fmt.int(st+1)} – ${fmt.int(Math.min(st+size, view.length))} / 총 ${fmt.int(view.length)} 건`
      : '0 건';
    let h = `<button ${page===1?'disabled':''} data-p="${page-1}">‹</button>`;
    for (let p=1; p<=pages; p++) h += `<button class="${p===page?'on':''}" data-p="${p}">${p}</button>`;
    h += `<button ${page===pages?'disabled':''} data-p="${page+1}">›</button>`;
    host.querySelector('.pages').innerHTML = h;

    const cnt = document.querySelector('[data-count]');
    if (cnt) cnt.textContent = fmt.int(view.length);
    const pg = document.querySelector('[data-pageinfo]');
    if (pg) pg.textContent = `Page ${page} of ${pages}`;
  }

  host.querySelector('.pages').addEventListener('click', e => {
    const b = e.target.closest('button[data-p]');
    if (b && !b.disabled) { page = +b.dataset.p; render(); }
  });

  host.querySelectorAll('thead th[data-key]').forEach(th => {
    if (th.dataset.key === '#') return;
    th.style.cursor = 'pointer';
    th.addEventListener('click', () => {
      const k = th.dataset.key;
      sortDir = (sortKey === k) ? -sortDir : 1; sortKey = k;
      view.sort((a,b) => typeof a[k] === 'number' ? (a[k]-b[k])*sortDir
                                                 : String(a[k]).localeCompare(String(b[k]))*sortDir);
      page = 1; render();
    });
  });

  /* 상단 검색바 연결 */
  const kw = document.querySelector('[data-search]');
  const runSearch = () => {
    const q = (kw?.value || '').trim().toLowerCase();
    view = q ? all.filter(r => Object.values(r).some(v => String(v).toLowerCase().includes(q))) : all.slice();
    page = 1; render();
  };
  if (kw){
    kw.addEventListener('input', runSearch);
    document.querySelector('[data-search-btn]')?.addEventListener('click', runSearch);
  }
  document.querySelector('[data-reset]')?.addEventListener('click', () => {
    if (kw) kw.value = '';
    document.querySelectorAll('.search-bar select, .filter-grid select, .filter-grid input')
            .forEach(el => el.value = '');
    view = all.slice(); page = 1; render();
  });

  /* CSV 내려받기 */
  document.querySelector('[data-csv]')?.addEventListener('click', () => {
    const head = cols.filter(c => c.key !== '#').map(c => c.label);
    const body = view.map(r => cols.filter(c => c.key !== '#').map(c => r[c.key]));
    const csv = '﻿' + [head, ...body].map(r => r.map(c => `"${c ?? ''}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8'}));
    a.download = (document.title.split('·')[0].trim() || 'ASM') + '.csv';
    a.click();
  });

  render();
  return { render, get view(){ return view; } };
}

/* ── 6. 모달 ─────────────────────────────────────────────────────────── */
function modal(sel, open){ document.querySelector(sel)?.classList.toggle('open', open !== false); }
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
});
document.addEventListener('click', e => {
  if (e.target.classList?.contains('modal-overlay')) e.target.classList.remove('open');
});

/* ── 7. 공개 ─────────────────────────────────────────────────────────── */
global.ASM = { MENU, USER, fmt, badge, mark, grid, modal };
document.addEventListener('DOMContentLoaded', buildShell);

})(window);
