# ASM 화면 시안 (Mock-up)

PT ASCENDO INTERNASIONAL · 2026-09-01
디자인 기준 : `ASM_디자인가이드_삼탄TMS기준_v1.0.html` (Google Drive · ASM 개발 폴더)
색상 원본 : SAMTAN TMS (hungaseo-arch.github.io/samtan) `src/index.css`

> **주의** — 실제 ASM 소스코드가 아닙니다. 화면 구조와 디자인 체계를 재현한 **시안**이며,
> 표시된 데이터는 전부 예시입니다. 각 화면 상단 노란 띠(`.mock-flag`)가 이를 표시합니다.

---

## 1. 시작하기

1. VSCode에서 이 폴더를 엽니다 (`File > Open Folder`).
2. 확장 **Live Server** 설치 후 `index.html` 우클릭 → *Open with Live Server*.
   (파일을 직접 더블클릭해도 열리지만, Live Server를 쓰면 저장 즉시 새로고침됩니다.)
3. `index.html` 이 15개 화면의 목록입니다.

## 2. 폴더 구조

```
asm-mockup/
├─ index.html                 화면 목록 (시작점)
├─ README.md                  이 문서
├─ _gen.py                    15개 화면 일괄 생성 스크립트
├─ assets/
│  ├─ asm-common.css          전 화면 공통 스타일 ★ 디자인은 여기만 수정
│  └─ asm-common.js           헤더·사이드바 생성 + 숫자포맷 + 표 로직
├─ sales/
│  ├─ quotation.html          Quotation           견적서
│  ├─ customer-po.html        Customer PO         고객 발주서 접수·관리
│  ├─ so.html                 Sales Order         수주
│  ├─ delivery-order.html     Delivery Order      출하지시서
│  └─ delivery-note.html      Delivery Note       납품확인서
├─ inventory/
│  ├─ stock-movement.html     Stock Movement      재고 입출고 내역
│  ├─ stock-adjustment.html   Stock Adjustment    재고 조정
│  ├─ stock-transfer.html     Stock Transfer      창고 간 이고
│  └─ stock-opname.html       Stock Opname        재고 실사
└─ master/
   ├─ item.html               Item Master         품목 마스터
   ├─ brand-pattern.html      Brand / Pattern     브랜드·패턴 마스터
   ├─ warehouse.html          Warehouse           창고 마스터
   ├─ user.html               User                사용자 계정
   ├─ role-permission.html    Role / Permission   권한 매트릭스
   └─ approval-matrix.html    Approval Matrix     승인 매트릭스
```

## 3. 수정 지점

| 바꾸고 싶은 것 | 고칠 파일 | 위치 |
|---|---|---|
| 색상·글꼴·여백·표 규격 | `assets/asm-common.css` | 상단 `:root` 토큰 |
| 상단메뉴·사이드바 항목 | `assets/asm-common.js` | 상단 `MENU` 배열 (한 곳만 고치면 전 화면 반영) |
| 로그인 사용자 표시 | `assets/asm-common.js` | `USER` 객체 |
| 표 컬럼 | 각 화면 `.html` | 하단 `columns: [...]` |
| 표 데이터 | 각 화면 `.html` | 하단 `const ROWS = [...]` |
| 15개 화면 일괄 변경 | `_gen.py` | 수정 후 `python3 _gen.py` |

## 4. 적용된 디자인 사양 (가이드 대비)

| 항목 | 적용값 | 가이드 절 |
|---|---|---|
| Primary | `#00306E` (hover `#004085` / active `#002252`) | 3-1 |
| 본문 글자 | 14 px · Inter + Noto Sans KR | 4-1, 4-2 |
| 숫자·문서번호 | JetBrains Mono · `tabular-nums` | 4-1 |
| 상단 액센트 바 | 4 px 네이비 · 최상단 고정 | 6-1 |
| 헤더 | 56 px · sticky · 활성 메뉴 네이비 배경 | 6-2 |
| 사이드바 | 220 px · `#F2F5F9` · 활성 좌측 3 px 인디케이터 | 6-3 |
| 버튼 | 36 px · radius 4 px · 5종 | 7-1 |
| 입력창 | 36 px · 포커스 링 `rgb(0 48 110 / .25)` | 7-2 |
| 카드 | radius 10 px · 패딩 24 px · shadow-sm | 7-3 |
| 상태 배지 | 20 px · 11 px/600 · 5색 (info/success/warning/danger/neutral) | 7-4, 3-2 |
| 표 헤더 | 40 px · 12 px/600 · `#EEF2F7` · 대문자 · sticky | 8-1 |
| 표 셀 | 13 px · 행높이 40 px · 패딩 8/12 px · 세로선 없음 | 8-1 |
| 숫자 열 | 우측정렬 + monospace, 날짜 열 중앙정렬 + 줄바꿈 금지 | 8-2 |
| 숫자 표기 | 영미식 (`1,250,000` / `84.25` / `12.5%`) | 8-3 |

### 가이드에 사양이 없어 임의 적용한 부분 (검토 필요)

1. **검색·필터 바** — 가이드에 전용 절이 없어, `--secondary #EAEFF5` 의 "필터 바" 용도 규정과
   현재 ASM 화면 배치(Search 라벨 + 조건 셀렉트 + 키워드 + 액션 버튼)를 따랐습니다.
2. **페이지네이션** — 가이드에 언급이 없어 버튼(7-1)과 색상 토큰만으로 구성했습니다.
3. **zebra 줄무늬** — 가이드가 hover 배경과 하단 구분선만 규정하므로 **적용하지 않았습니다.**
4. **정렬(sort) UI** — 열 정렬(alignment) 규칙만 있고 클릭 정렬 사양이 없어, 헤더 클릭 시
   정렬되도록만 구현하고 아이콘은 넣지 않았습니다.
5. **표 세로 스크롤** — 헤더 고정(sticky)이 동작하려면 스크롤 컨테이너가 필요하여
   `.table-wrap { max-height: calc(100vh - 300px) }` 를 적용했습니다.

### 가이드 내부 값 불일치 2건 (개발사 회신 전 확인 필요)

| 항목 | 7장 본문 | 10장 코드 | 본 시안 채택 |
|---|---|---|---|
| 입력창 포커스 링 투명도 | `.5` | `.25` | `.25` (코드 기준) |
| 상태 배지 글자 크기 | 11 px (7-4) | 11 px | 11 px |

※ 4-2 크기 체계 표는 배지를 `text-xs` 12 px 로 적고 있어 7-4(11 px)와 다릅니다.

## 5. 실서비스 연결

각 화면 하단의

```js
const ROWS = [ ... ];
```

를 아래로 바꾸면 나머지(검색·정렬·페이지네이션·합계·CSV)는 그대로 동작합니다.

```js
const ROWS = await (await fetch('/api/quotation')).json();
```

## 6. 브라우저 지원

Chrome / Edge 최신 버전 기준. 외부 라이브러리 의존 없음(웹폰트만 Google Fonts에서 로드).
사내망에서 폰트 로드가 막히면 `asm-common.css` 최상단 `@import` 를 지우고
`--font-sans` 의 대체 글꼴(맑은 고딕 등)로 표시됩니다.
