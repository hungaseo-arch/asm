# -*- coding: utf-8 -*-
"""ASM 화면 목업 생성기 — 화면 정의를 고쳐 다시 실행하면 전 화면이 갱신됩니다."""
import json, os, random, datetime as dt

ROOT = os.path.expanduser('~/asm-mockup')
random.seed(20260901)

CUST = ['PT Bukit Makmur Mandiri','PT Pamapersada Nusantara','PT Kaltim Prima Coal',
        'PT Saptaindra Sejati','PT Thiess Contractors Indonesia','PT Putra Perkasa Abadi',
        'PT Berau Coal','PT Darma Henwa','PT Cipta Kridatama','PT Ulima Nitra']
REP  = ['Hery','Hanif','Eri','Arif','Rizki']
WH   = ['Cikarang WH','Surabaya WH','Semarang WH','Balikpapan WH','Palembang WH']
SIZE = ['26.5R25','23.5R25','29.5R25','1200R24','1100R20','750-16','825-16','700-12','18.4-34','1000R20']
PATT = ['E3/L3','ETSM','AS-668','AS-108','FL-01','R-1','E4','AS-661','AS-682','E3']
CATG = ['OTR','TB-R','TB-B','IND','AGR']
PAY  = ['CBD','30 Days','45 Days','60 Days','L/C at sight']

def d(off):  return (dt.date(2026,9,1) + dt.timedelta(days=off)).isoformat()

# ── 화면 정의 ──────────────────────────────────────────────────────────
# cols : (key, LABEL, cls, fmt)  cls = '' | num | date | ctr | code | ell
SCREENS = []

def add(**kw): SCREENS.append(kw)

# ══ SALES ══════════════════════════════════════════════════════════════
add(dirn='sales', slug='quotation', menu='Sales', sub='Quotation',
    title='Quotation', desc='Penawaran Harga · 견적서',
    ph='Customer, Quote name, Quote no, Status', new='NEW QUOTATION',
    cols=[('#','#','ctr',None),('no','QUOTE NO.','code',None),('name','QUOTE NAME','ell',None),
          ('pono','PO NO.','code',None),('cust','CUSTOMER','ell',None),
          ('qty','QTY','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('pay','PAYMENT','ctr',None),('eta','EST DELIV. DATE','date',None),
          ('rep','SALES REP','ctr',None),('rmk','REMARK','ell',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty','amt'], totspan=5,
    rows=[dict(no=f'QT-2608-{100+i:03d}', name=f'{random.choice(CATG)} Tire Supply {2026}',
               pono=f'PO-{random.randint(70000,79999)}', cust=random.choice(CUST),
               qty=random.choice([24,48,96,120,240,360,480]),
               amt=random.randint(18000,420000), pay=random.choice(PAY), eta=d(random.randint(7,90)),
               rep=random.choice(REP), rmk=random.choice(['Revisi harga ke-2','Menunggu approval','—','Sample 4 EA','Include delivery']),
               st=random.choice(['DRAFT','PENDING','CONFIRMED','APPROVED','REJECTED','CANCELED']))
          for i in range(24)])

add(dirn='sales', slug='customer-po', menu='Sales', sub='Customer PO',
    title='Customer PO', desc='PO Pelanggan · 고객 발주서 접수·관리',
    ph='Customer, PO no, Quote no, Status', new='NEW CUSTOMER PO',
    cols=[('#','#','ctr',None),('no','PO NO.','code',None),('dt','PO DATE','date',None),
          ('cust','CUSTOMER','ell',None),('qno','QUOTE NO.','code',None),
          ('qty','QTY','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('pay','PAYMENT','ctr',None),('req','REQ DELIV. DATE','date',None),
          ('rep','SALES REP','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty','amt'], totspan=5,
    rows=[dict(no=f'CPO-2608-{200+i:03d}', dt=d(-random.randint(1,60)), cust=random.choice(CUST),
               qno=f'QT-2608-{100+random.randint(0,23):03d}',
               qty=random.choice([24,48,96,144,240,480]), amt=random.randint(15000,380000),
               pay=random.choice(PAY), req=d(random.randint(5,75)), rep=random.choice(REP),
               st=random.choice(['PENDING','CONFIRMED','PARTIAL','COMPLETED','CANCELED']))
          for i in range(21)])

add(dirn='sales', slug='so', menu='Sales', sub='SO',
    title='Sales Order', desc='Pesanan Penjualan · 수주',
    ph='Customer, SO no, PO no, Status', new='NEW SO',
    cols=[('#','#','ctr',None),('no','SO NO.','code',None),('dt','SO DATE','date',None),
          ('cust','CUSTOMER','ell',None),('pono','PO NO.','code',None),
          ('qty','ORDER QTY','num','ASM.fmt.int'),('dlv','DELIVERED','num','ASM.fmt.int'),
          ('bal','BALANCE','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('wh','WAREHOUSE','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty','dlv','bal','amt'], totspan=5,
    rows=[(lambda q,dl: dict(no=f'SO-2608-{300+i:03d}', dt=d(-random.randint(1,50)),
               cust=random.choice(CUST), pono=f'CPO-2608-{200+random.randint(0,20):03d}',
               qty=q, dlv=dl, bal=q-dl, amt=random.randint(12000,300000), wh=random.choice(WH),
               st='COMPLETED' if q==dl else ('PARTIAL' if dl>0 else 'OPEN')))(
           *(lambda q: (q, random.choice([0, q//2, q])))(random.choice([48,96,144,240,360])))
          for i in range(19)])

add(dirn='sales', slug='delivery-order', menu='Sales', sub='Delivery Order',
    title='Delivery Order', desc='Surat Jalan (DO) · 출하지시서',
    ph='Customer, DO no, SO no, Vehicle no', new='NEW DO',
    cols=[('#','#','ctr',None),('no','DO NO.','code',None),('dt','DO DATE','date',None),
          ('sono','SO NO.','code',None),('cust','CUSTOMER','ell',None),
          ('wh','WAREHOUSE','ctr',None),('qty','QTY','num','ASM.fmt.int'),
          ('drv','DRIVER','ctr',None),('veh','VEHICLE NO.','code',None),
          ('eta','EST ARRIVAL','date',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty'], totspan=6,
    rows=[dict(no=f'DO-2608-{400+i:03d}', dt=d(-random.randint(0,30)),
               sono=f'SO-2608-{300+random.randint(0,18):03d}', cust=random.choice(CUST),
               wh=random.choice(WH), qty=random.choice([12,24,36,48,96,120]),
               drv=random.choice(['Budi','Agus','Slamet','Wayan','Joko']),
               veh=random.choice(['B 9123 UYZ','L 8871 KP','H 4420 ND','KT 7712 AL','BG 3390 QN']),
               eta=d(random.randint(0,14)),
               st=random.choice(['ISSUED','IN TRANSIT','DELIVERED','PENDING','CANCELED']))
          for i in range(18)])

add(dirn='sales', slug='delivery-note', menu='Sales', sub='Delivery Note',
    title='Delivery Note', desc='Bukti Terima Barang · 납품확인서',
    ph='Customer, DN no, DO no, Received by', new='NEW DN',
    cols=[('#','#','ctr',None),('no','DN NO.','code',None),('dt','DN DATE','date',None),
          ('dono','DO NO.','code',None),('cust','CUSTOMER','ell',None),
          ('qty','QTY','num','ASM.fmt.int'),('amt','AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('rcv','RECEIVED BY','ctr',None),('rdt','RECEIVED DATE','date',None),
          ('st','STATUS','ctr','ASM.badge')],
    total=['qty','amt'], totspan=5,
    rows=[dict(no=f'DN-2608-{500+i:03d}', dt=d(-random.randint(0,28)),
               dono=f'DO-2608-{400+random.randint(0,17):03d}', cust=random.choice(CUST),
               qty=random.choice([12,24,36,48,96]), amt=random.randint(8000,160000),
               rcv=random.choice(['Sdr. Iwan','Sdr. Nanang','Sdri. Rina','Sdr. Bagus','Sdr. Hendra']),
               rdt=d(-random.randint(0,25)),
               st=random.choice(['RECEIVED','PENDING','PARTIAL','DELIVERED']))
          for i in range(17)])

# ══ INVENTORY ══════════════════════════════════════════════════════════
add(dirn='inventory', slug='stock-movement', menu='Inventory', sub='Stock Movement',
    title='Stock Movement', desc='Mutasi Stok · 재고 입출고 내역',
    ph='Doc no, Item code, Size, Warehouse', new=None,
    cols=[('#','#','ctr',None),('dt','DATE','date',None),('doc','DOC NO.','code',None),
          ('typ','TYPE','ctr','ASM.badge'),('wh','WAREHOUSE','ctr',None),
          ('code','ITEM CODE','code',None),('size','SIZE','',None),('patt','PATTERN','',None),
          ('inq','IN','num','ASM.fmt.int'),('outq','OUT','num','ASM.fmt.int'),
          ('bal','BALANCE','num','ASM.fmt.int'),('rmk','REMARK','ell',None)],
    total=['inq','outq'], totspan=8,
    rows=[(lambda t: dict(dt=d(-random.randint(0,45)),
               doc=f'{"RC" if t=="RECEIVED" else "DN"}-2608-{600+i:03d}', typ=t,
               wh=random.choice(WH), code=f'{random.choice(CATG)}-{random.randint(1000,9999)}',
               size=random.choice(SIZE), patt=random.choice(PATT),
               inq=random.choice([0,24,48,120,240]) if t=='RECEIVED' else 0,
               outq=0 if t=='RECEIVED' else random.choice([12,24,36,48]),
               bal=random.randint(20,900),
               rmk=random.choice(['Import container','Penjualan','Transfer masuk','Adjustment','—'])))(
           random.choice(['RECEIVED','DELIVERED','POSTED']))
          for i in range(26)])

add(dirn='inventory', slug='stock-adjustment', menu='Inventory', sub='Stock Adjustment',
    title='Stock Adjustment', desc='Penyesuaian Stok · 재고 조정',
    ph='Adj no, Item code, Warehouse, Reason', new='NEW ADJUSTMENT',
    cols=[('#','#','ctr',None),('no','ADJ NO.','code',None),('dt','ADJ DATE','date',None),
          ('wh','WAREHOUSE','ctr',None),('code','ITEM CODE','code',None),('size','SIZE','',None),
          ('sys','SYSTEM QTY','num','ASM.fmt.int'),('act','ACTUAL QTY','num','ASM.fmt.int'),
          ('dif','DIFF','num','v=>(v>0?"+":"")+ASM.fmt.int(v)'),
          ('rsn','REASON','ell',None),('req','REQUESTED BY','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['sys','act','dif'], totspan=6,
    rows=[(lambda s,a: dict(no=f'ADJ-2608-{700+i:03d}', dt=d(-random.randint(0,40)),
               wh=random.choice(WH), code=f'{random.choice(CATG)}-{random.randint(1000,9999)}',
               size=random.choice(SIZE), sys=s, act=a, dif=a-s,
               rsn=random.choice(['Selisih hitung fisik','Barang rusak (defect)','Salah input DO',
                                  'Retur pelanggan','Temuan stock opname']),
               req=random.choice(['Firman','Komang','Rizki','Hery']),
               st=random.choice(['DRAFT','PENDING','APPROVED','REJECTED','POSTED'])))(
           *(lambda s: (s, s + random.choice([-8,-4,-2,-1,1,2,5])))(random.randint(20,400)))
          for i in range(16)])

add(dirn='inventory', slug='stock-transfer', menu='Inventory', sub='Stock Transfer',
    title='Stock Transfer', desc='Transfer Antar Gudang · 창고 간 이고',
    ph='Trf no, Item code, From WH, To WH', new='NEW TRANSFER',
    cols=[('#','#','ctr',None),('no','TRF NO.','code',None),('dt','TRF DATE','date',None),
          ('fwh','FROM WH','ctr',None),('twh','TO WH','ctr',None),
          ('code','ITEM CODE','code',None),('size','SIZE','',None),
          ('qty','QTY','num','ASM.fmt.int'),('veh','VEHICLE NO.','code',None),
          ('eta','EST ARRIVAL','date',None),('st','STATUS','ctr','ASM.badge')],
    total=['qty'], totspan=7,
    rows=[(lambda f: dict(no=f'TRF-2608-{800+i:03d}', dt=d(-random.randint(0,35)), fwh=f,
               twh=random.choice([w for w in WH if w != f]),
               code=f'{random.choice(CATG)}-{random.randint(1000,9999)}', size=random.choice(SIZE),
               qty=random.choice([12,24,48,60,120]),
               veh=random.choice(['B 9123 UYZ','L 8871 KP','H 4420 ND','KT 7712 AL']),
               eta=d(random.randint(0,12)),
               st=random.choice(['ISSUED','IN TRANSIT','RECEIVED','PENDING','CANCELED'])))(random.choice(WH))
          for i in range(15)])

add(dirn='inventory', slug='stock-opname', menu='Inventory', sub='Stock Opname',
    title='Stock Opname', desc='Perhitungan Fisik Stok · 재고 실사',
    ph='Opname no, Warehouse, Period, PIC', new='NEW OPNAME',
    cols=[('#','#','ctr',None),('no','OPNAME NO.','code',None),('prd','PERIOD','ctr',None),
          ('wh','WAREHOUSE','ctr',None),('tsku','TOTAL SKU','num','ASM.fmt.int'),
          ('csku','COUNTED','num','ASM.fmt.int'),('dsku','DIFF SKU','num','ASM.fmt.int'),
          ('dqty','DIFF QTY','num','v=>(v>0?"+":"")+ASM.fmt.int(v)'),
          ('dval','DIFF VALUE','num','v=>ASM.fmt.cur("USD",v)'),
          ('rate','PROGRESS','num','ASM.fmt.pct'),
          ('pic','PIC','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['tsku','csku','dsku','dqty','dval'], totspan=4,
    rows=[(lambda t,c: dict(no=f'OPN-26{m:02d}-{900+i:03d}', prd=f'2026-{m:02d}',
               wh=random.choice(WH), tsku=t, csku=c, dsku=random.randint(0,9),
               dqty=random.choice([-14,-6,-2,0,3,8]), dval=random.randint(-4200,3800),
               rate=round(c/t*100,1),
               pic=random.choice(['Firman','Komang','Hery','Hanif']),
               st='COMPLETED' if c==t else ('PENDING' if c>0 else 'DRAFT')))(
           *(lambda t: (t, random.choice([t, t, int(t*0.6), 0])))(random.randint(120,480)))
          for i,m in enumerate([4,5,5,6,6,7,7,8,8,8,9,9])])

# ══ MASTER DATA ════════════════════════════════════════════════════════
add(dirn='master', slug='item', menu='Master Data', sub='Item',
    title='Item Master', desc='Master Barang · 품목 마스터',
    ph='Item code, Size, Pattern, Brand', new='NEW ITEM',
    cols=[('#','#','ctr',None),('code','ITEM CODE','code',None),('cat','CATEGORY','ctr',None),
          ('brand','BRAND','',None),('size','SIZE','',None),('patt','PATTERN','',None),
          ('pr','PR / TL','ctr',None),('wt','WEIGHT','num','ASM.fmt.kg'),
          ('hs','HS CODE','code',None),('uom','UOM','ctr',None),
          ('cost','STD COST (USD)','num','ASM.fmt.price'),('st','STATUS','ctr','ASM.badge')],
    total=None, totspan=1,
    rows=[dict(code=f'{random.choice(CATG)}-{random.randint(1000,9999)}', cat=random.choice(CATG),
               brand=random.choice(['Ascendo','Techking','Solideal','Arami']),
               size=random.choice(SIZE), patt=random.choice(PATT),
               pr=random.choice(['**','12PR','14PR','16PR','18PR','20PR','40PR','—']),
               wt=round(random.uniform(18,412),1),
               hs=random.choice(['4011.80.00','4011.20.10','4011.70.00','4011.90.00']),
               uom='EA', cost=round(random.uniform(58,2380),2),
               st=random.choice(['ACTIVE','ACTIVE','ACTIVE','INACTIVE']))
          for i in range(28)])

add(dirn='master', slug='brand-pattern', menu='Master Data', sub='Brand / Pattern',
    title='Brand / Pattern', desc='Merek & Pola Tapak · 브랜드·패턴 마스터',
    ph='Brand, Pattern, Category, Factory', new='NEW PATTERN',
    cols=[('#','#','ctr',None),('brand','BRAND','',None),('patt','PATTERN','code',None),
          ('cat','CATEGORY','ctr',None),('app','APPLICATION','ell',None),
          ('org','ORIGIN','ctr',None),('fac','FACTORY','ell',None),
          ('cnt','ITEM COUNT','num','ASM.fmt.int'),('st','STATUS','ctr','ASM.badge')],
    total=['cnt'], totspan=7,
    rows=[dict(brand=b, patt=p, cat=c, app=a, org=o, fac=f, cnt=random.randint(3,46),
               st=random.choice(['ACTIVE','ACTIVE','INACTIVE']))
          for b,p,c,a,o,f in [
            ('Ascendo','AS-668','TB-R','Long haul / on-road','China','Dongying Rungold Tyre'),
            ('Ascendo','AS-682','TB-R','Mixed service / on-off road','China','Dongying Rungold Tyre'),
            ('Ascendo','AS-661','TB-R','Regional distribution','China','Dongying Rungold Tyre'),
            ('Ascendo','AS-108','TB-B','Light truck bias','Indonesia','PT Arami Jaya'),
            ('Ascendo','E3/L3','OTR','Loader / dump truck','China','Techking OEM'),
            ('Ascendo','E4','OTR','Rigid dump truck (deep tread)','China','Techking OEM'),
            ('Ascendo','FL-01','IND','Forklift pneumatic','Indonesia','PT Arami Jaya'),
            ('Ascendo','R-1','AGR','Tractor rear','China','Dongying Rungold Tyre'),
            ('Techking','ETSM','OTR','Mining haul / scraper','China','Techking Tires'),
            ('Solideal','SOLID','IND','Forklift solid / press-on','Sri Lanka','Camso Loadstar'),
            ('Arami','ARM-TB','TB-B','Bias truck local','Indonesia','PT Arami Jaya'),
            ('Arami','ARM-IT','IND','Inner tube (ban dalam)','Indonesia','PT Arami Jaya')]])

add(dirn='master', slug='warehouse', menu='Master Data', sub='Warehouse',
    title='Warehouse', desc='Gudang · 창고 마스터',
    ph='WH code, Warehouse name, City, PIC', new='NEW WAREHOUSE',
    cols=[('#','#','ctr',None),('code','WH CODE','code',None),('nm','WAREHOUSE NAME','ell',None),
          ('typ','TYPE','ctr',None),('city','CITY','',None),('addr','ADDRESS','ell',None),
          ('pic','PIC','ctr',None),('cap','CAPACITY (EA)','num','ASM.fmt.int'),
          ('cur','CURRENT (EA)','num','ASM.fmt.int'),('util','UTIL.','num','ASM.fmt.pct'),
          ('st','STATUS','ctr','ASM.badge')],
    total=['cap','cur'], totspan=7,
    rows=[(lambda cap,cur: dict(code=c, nm=n, typ=t, city=ct, addr=ad, pic=p,
               cap=cap, cur=cur, util=round(cur/cap*100,1),
               st='ACTIVE' if act else 'INACTIVE'))(cp,cr)
          for c,n,t,ct,ad,p,cp,cr,act in [
            ('WH-CKR','Cikarang Main Warehouse','Main','Cikarang','Jl. Jababeka Raya Blok F, Kawasan Industri','Firman',12000,8420,True),
            ('WH-SBY','Surabaya Branch Warehouse','Branch','Surabaya','Jl. Margomulyo Indah No. 12','Hery',6000,4130,True),
            ('WH-SMG','Semarang Branch Warehouse','Branch','Semarang','Jl. Raya Kaligawe KM 5','Hanif',4500,2680,True),
            ('WH-BPP','Balikpapan Branch Warehouse','Branch','Balikpapan','Jl. Mulawarman No. 88, Manggar','Arif',3500,1940,True),
            ('WH-PLB','Palembang Branch Warehouse','Branch','Palembang','Jl. Soekarno Hatta KM 9','Rizki',3000,860,True),
            ('WH-TRN','Transit / In-Transit Stock','Transit','—','Dalam perjalanan antar gudang','—',2000,320,True),
            ('WH-QAR','Quarantine / Defect Area','Quarantine','Cikarang','Jl. Jababeka Raya Blok F (Zona B)','Firman',800,214,True),
            ('WH-OLD','Jakarta Old Warehouse','Branch','Jakarta','Jl. Daan Mogot KM 12','—',2500,0,False)]])

# ══ SETTINGS ═══════════════════════════════════════════════════════════
add(dirn='master', slug='user', menu='Settings', sub='User',
    title='User', desc='Pengguna · 사용자 계정 관리',
    ph='User ID, Name, Department, Role', new='NEW USER',
    cols=[('#','#','ctr',None),('uid','USER ID','code',None),('nm','NAME','',None),
          ('dept','DEPARTMENT','',None),('pos','POSITION','ell',None),
          ('mail','EMAIL','ell',None),('role','ROLE','ctr',None),
          ('last','LAST LOGIN','date',None),('st','STATUS','ctr','ASM.badge')],
    total=None, totspan=1,
    rows=[dict(uid=u, nm=n, dept=dp, pos=ps, mail=f'{u}@ascendotyre.com', role=r,
               last=d(-random.randint(0,20)), st=s)
          for u,n,dp,ps,r,s in [
            ('seo','Seo Hunga','Management','General Manager','ADMIN','ACTIVE'),
            ('hery','Hery','Sales','Sales Rep — Surabaya','SALES','ACTIVE'),
            ('hanif','Hanif','Sales','Sales Rep — Central/East Java','SALES','ACTIVE'),
            ('eri','Eri','Sales','Sales Rep — Jakarta','SALES','ACTIVE'),
            ('arif','Arif','Sales','Sales Rep — West Kalimantan','SALES','ACTIVE'),
            ('rizki','Rizki','Sales','Field Team','SALES','ACTIVE'),
            ('firman','Firman','Warehouse','Warehouse Staff','WAREHOUSE','ACTIVE'),
            ('komang','Komang','Finance','Finance Staff','FINANCE','ACTIVE'),
            ('purch01','Andi Pratama','Purchasing','Import Staff','PURCHASING','ACTIVE'),
            ('acc01','Sri Wahyuni','Finance','Accounting Staff','FINANCE','ACTIVE'),
            ('audit01','External Auditor','—','Read-only Access','VIEWER','INACTIVE')]])

add(dirn='master', slug='role-permission', menu='Settings', sub='Role / Permission',
    title='Role / Permission', desc='Peran & Hak Akses · 권한 매트릭스',
    ph='Role code, Role name, Module', new='NEW ROLE',
    cols=[('#','#','ctr',None),('rc','ROLE CODE','code',None),('rn','ROLE NAME','ell',None),
          ('mod','MODULE','',None),('v','VIEW','ctr','ASM.mark'),('c','CREATE','ctr','ASM.mark'),
          ('e','EDIT','ctr','ASM.mark'),('dl','DELETE','ctr','ASM.mark'),
          ('ap','APPROVE','ctr','ASM.mark'),('ex','EXPORT','ctr','ASM.mark'),
          ('cnt','USERS','num','ASM.fmt.int')],
    total=None, totspan=1,
    rows=[dict(rc=rc, rn=rn, mod=m, v=v, c=c, e=e, dl=dl, ap=ap, ex=ex, cnt=n)
          for rc,rn,m,v,c,e,dl,ap,ex,n in [
            ('ADMIN','System Administrator','All Modules',1,1,1,1,1,1,1),
            ('SALES','Sales Representative','Sales',1,1,1,0,0,1,5),
            ('SALES','Sales Representative','Inventory',1,0,0,0,0,0,5),
            ('SALES','Sales Representative','Partners',1,1,1,0,0,0,5),
            ('PURCHASING','Purchasing / Import Staff','Purchasing',1,1,1,0,0,1,1),
            ('PURCHASING','Purchasing / Import Staff','Inventory',1,0,0,0,0,1,1),
            ('WAREHOUSE','Warehouse Staff','Inventory',1,1,1,0,0,1,1),
            ('WAREHOUSE','Warehouse Staff','Sales',1,0,1,0,0,0,1),
            ('FINANCE','Finance / Accounting','Sales',1,0,0,0,1,1,2),
            ('FINANCE','Finance / Accounting','Purchasing',1,0,0,0,1,1,2),
            ('MANAGER','Department Manager','All Modules',1,1,1,0,1,1,0),
            ('VIEWER','Read-only / Auditor','All Modules',1,0,0,0,0,1,1)]])

add(dirn='master', slug='approval-matrix', menu='Settings', sub='Approval Matrix',
    title='Approval Matrix', desc='Matriks Persetujuan · 승인 매트릭스',
    ph='Doc type, Approver, Status', new='NEW RULE',
    cols=[('#','#','ctr',None),('doc','DOC TYPE','ell',None),
          ('lim','AMOUNT LIMIT','num','v=>v?ASM.fmt.cur("USD",v):"무제한"'),
          ('s1','STEP 1','ctr',None),('s2','STEP 2','ctr',None),('s3','STEP 3','ctr',None),
          ('sod','SoD RULE','ell',None),('eff','EFFECTIVE DATE','date',None),
          ('st','STATUS','ctr','ASM.badge')],
    total=None, totspan=1,
    rows=[dict(doc=dc, lim=lm, s1=a1, s2=a2, s3=a3, sod=sd, eff=ef, st=st)
          for dc,lm,a1,a2,a3,sd,ef,st in [
            ('Quotation', 50000,'Sales Rep','Sales Manager','—','기안자 승인 불가','2026-01-01','ACTIVE'),
            ('Quotation', 0,'Sales Rep','Sales Manager','General Manager','기안자 승인 불가','2026-01-01','ACTIVE'),
            ('Customer PO', 100000,'Sales Manager','Finance','—','여신한도 초과 시 Finance 필수','2026-01-01','ACTIVE'),
            ('Sales Order', 0,'Sales Manager','Finance','General Manager','재고 미확보 시 반려','2026-01-01','ACTIVE'),
            ('Delivery Order', 0,'Warehouse Staff','Warehouse Manager','—','출고자·승인자 분리','2026-03-01','ACTIVE'),
            ('Purchase PO', 200000,'Purchasing Staff','Purchasing Manager','—','발주자 승인 불가','2026-01-01','ACTIVE'),
            ('Purchase PO', 0,'Purchasing Staff','Purchasing Manager','General Manager','발주자 승인 불가','2026-01-01','ACTIVE'),
            ('Stock Adjustment', 5000,'Warehouse Staff','Warehouse Manager','—','실사자·승인자 분리','2026-03-01','ACTIVE'),
            ('Stock Adjustment', 0,'Warehouse Staff','Warehouse Manager','General Manager','실사자·승인자 분리','2026-03-01','ACTIVE'),
            ('Stock Transfer', 0,'Warehouse Staff','Warehouse Manager','—','출고창고·입고창고 각각 확인','2026-03-01','ACTIVE'),
            ('Credit Note', 0,'Finance','Finance Manager','General Manager','발행자 승인 불가','2026-05-01','ACTIVE'),
            ('Master Data 변경', 0,'해당 부서','System Administrator','—','데이터 오너 승인 필수','2026-06-01','PENDING')]])


# ══ PURCHASING ═════════════════════════════════════════════════════════
# 아래 9개 화면의 컬럼·검색조건·필터는 2026-09-01 실제 ASM 화면에서 읽어 그대로 옮긴 것입니다.
SUP_IMP = ['HUBEI AULICE TYRE CO.,LTD','HUA IN GLOBAL (SHANGHAI) CO., LTD',
           'DONGYING RUNGOLD TYRE CO., LTD','TECHKING TIRES LIMITED']
SUP_LOC = ['PT. DIAMOND FAJAR JAYA','PT. ARAMI JAYA','PT. MULTISTRADA ARAH SARANA']
HANDLER = ['SEO JONG HWAN','ANDI PRATAMA','SRI WAHYUNI']
SEGS    = ['Keyword','Date']
CHIPS   = ['ALL','LOCAL','IMPORT']

def sup(imp=None):
    if imp is True:  return random.choice(SUP_IMP)
    if imp is False: return random.choice(SUP_LOC)
    return random.choice(SUP_IMP + SUP_LOC)

def pono(name, i, pfx='PO'):
    ini = ''.join(w[0] for w in name.replace('PT.','').split() if w[0].isalpha())[:2].upper()
    return f'{ini}-2026{random.choice([7,8,9]):02d}{random.randint(1,28):02d}-{i%9+1:03d}'

add(dirn='purchasing', slug='vendor-po', menu='Purchasing', sub='Purchase PO',
    title='Purchase PO', desc='PO Main · Pesanan Pembelian · 자사 구매발주서 관리',
    listlabel='All POs', ph='Supplier, PO no, Local/Import, Warehouse, Status',
    new='NEW', segs=SEGS, chips=CHIPS,
    cols=[('#','#','ctr',None),('no','PO NO.','code',None),('sup','SUPPLIER','ell',None),
          ('qty','QTY','num','ASM.fmt.int'),
          ('amt','AMOUNT','num','(v,r)=>ASM.fmt.cur(r.cur,v)'),
          ('eta','ETA','date',None),('rmk','REMARK','ell',None),
          ('st','STATUS','ctr','ASM.badge'),('hdl','HANDLER','ctr',None)],
    total=['qty'], totspan=3,
    rows=[(lambda n,im: dict(no=pono(n,i), sup=n,
             qty=random.choice([200,400,600,800,1200,1600]),
             amt=random.randint(80000,180000) if im else random.randint(420000000,1800000000),
             cur='USD' if im else 'IDR', eta=d(random.randint(5,120)),
             rmk=random.choice(['—','추가 발주분','컨테이너 2대','우선 선적 요청','환율 확정 후 진행']),
             st=random.choice(['DRAFT','CONFIRMED','APPROVED','PENDING','COMPLETED','CANCELED']),
             hdl=random.choice(HANDLER)))(
         *(lambda im: (sup(im), im))(random.choice([True,True,False])))
      for i in range(18)])

add(dirn='purchasing', slug='ppc', menu='Purchasing', sub='PPC',
    title='PPC', desc='PPC Main · Production Planning & Control · 공장 생산계획·진행 관리',
    listlabel='All PPCs', ph='Supplier, PO no, Warehouse, Local/Import, Status',
    new='NEW', segs=SEGS,
    cols=[('#','#','ctr',None),('sup','SUPPLIER','ell',None),('no','PO NO.','code',None),
          ('poq','PO QTY','num','ASM.fmt.int'),('qty','QTY','num','ASM.fmt.int'),
          ('amt','AMOUNT','num','(v,r)=>ASM.fmt.cur(r.cur,v)'),
          ('shp','SHP STATUS','ctr','ASM.badge'),('st','STATUS','ctr','ASM.badge'),
          ('req','REQ. ETA','date',None),('etd','ETD','date',None),('eta','ETA','date',None)],
    total=['poq','qty'], totspan=3,
    rows=[(lambda n,im,q: dict(sup=n, no=pono(n,i), poq=q, qty=random.choice([q, q, q//2]),
             amt=random.randint(70000,160000) if im else random.randint(380000000,1500000000),
             cur='USD' if im else 'IDR',
             shp=random.choice(['PENDING','IN TRANSIT','COMPLETED','DRAFT']),
             st=random.choice(['CONFIRMED','APPROVED','PENDING','COMPLETED']),
             req=d(random.randint(10,110)), etd=d(random.randint(3,80)), eta=d(random.randint(10,110))))(
         *(lambda im: (sup(im), im, random.choice([200,400,800,1200])))(random.choice([True,True,False])))
      for i in range(16)])

add(dirn='purchasing', slug='shipment', menu='Purchasing', sub='Shipment',
    title='Shipment', desc='Shipment Main · Pengiriman · 선적 관리',
    listlabel='All Shipments', ph='Supplier, Shipment no, PO no', new='NEW', segs=SEGS,
    cols=[('#','#','ctr',None),('sup','SUPPLIER','ell',None),('no','SHP NO.','code',None),
          ('pono','PO NO.','code',None),('sdt','SHP DATE','date',None),
          ('etd','ETD','date',None),('eta','ETA','date',None),('ata','ATA','date',None),
          ('poq','PO QTY','num','ASM.fmt.int'),('ppq','PPC QTY','num','ASM.fmt.int'),
          ('shq','SHP QTY','num','ASM.fmt.int'),('st','STATUS','ctr','ASM.badge')],
    total=['poq','ppq','shq'], totspan=3,
    rows=[(lambda n,q,arr: dict(sup=n, no=f'SHP-2026{random.choice([7,8,9]):02d}-{100+i:03d}',
             pono=pono(n,i), sdt=d(-random.randint(5,70)), etd=d(-random.randint(0,60)),
             eta=d(random.randint(-30,45)), ata=(d(-random.randint(0,25)) if arr else ''),
             poq=q, ppq=q, shq=random.choice([q, q, q//2]),
             st='RECEIVED' if arr else random.choice(['IN TRANSIT','ISSUED','PENDING'])))(
         sup(True), random.choice([200,400,800,1200]), random.choice([True,False]))
      for i in range(15)])

add(dirn='purchasing', slug='customs', menu='Purchasing', sub='Customs',
    title='Customs', desc='Customs Main · Bea Cukai (PIB) · 통관 관리',
    listlabel='All Customs', ph='Supplier, PO no, Customs no', new='NEW', segs=SEGS,
    cols=[('#','#','ctr',None),('sup','SUPPLIER','ell',None),('no','CUSTOMS NO.','code',None),
          ('pono','SUPPLIER PO NO.','code',None),('shp','SHIPMENT NO.','code',None),
          ('dt','DATE','date',None),('poq','PO QTY','num','ASM.fmt.int'),
          ('shq','SHP QTY','num','ASM.fmt.int'),('st','STATUS','ctr','ASM.badge')],
    total=['poq','shq'], totspan=3,
    rows=[(lambda n,q: dict(sup=n, no=f'PIB-2026{random.choice([7,8,9]):02d}-{random.randint(100000,999999)}',
             pono=pono(n,i), shp=f'SHP-2026{random.choice([7,8]):02d}-{100+i:03d}',
             dt=d(-random.randint(0,55)), poq=q, shq=random.choice([q, q//2]),
             st=random.choice(['PENDING','APPROVED','COMPLETED','DELAYED'])))(
         sup(True), random.choice([200,400,800,1200]))
      for i in range(14)])

add(dirn='purchasing', slug='receipts', menu='Purchasing', sub='Receipt',
    title='Receipt', desc='Receipt Main · Penerimaan Barang · 입고 (검수 기준)',
    listlabel='All Receipts', ph='PO no, Supplier, Warehouse',
    new='NEW', segs=SEGS, chips=CHIPS,
    cols=[('#','#','ctr',None),('sup','SUPPLIER','ell',None),('no','RECEIPT NO.','code',None),
          ('rdt','RECEIPT DATE','date',None),('pono','PO NO.','code',None),
          ('arr','ACT. ARRIVAL','date',None),('psq','PPC/SHP QTY','num','ASM.fmt.int'),
          ('qty','QTY','num','ASM.fmt.int'),
          ('amt','AMOUNT','num','(v,r)=>ASM.fmt.cur(r.cur,v)'),('st','STATUS','ctr','ASM.badge')],
    total=['psq','qty'], totspan=3,
    rows=[(lambda n,im,q: dict(sup=n, no=f'RC-2026{random.choice([7,8,9]):02d}-{200+i:03d}',
             rdt=d(-random.randint(0,50)), pono=pono(n,i), arr=d(-random.randint(0,50)),
             psq=q, qty=random.choice([q, q, q-8]),
             amt=random.randint(60000,150000) if im else random.randint(320000000,1300000000),
             cur='USD' if im else 'IDR',
             st=random.choice(['RECEIVED','PARTIAL','PENDING','COMPLETED'])))(
         *(lambda im: (sup(im), im, random.choice([200,400,800])))(random.choice([True,True,False])))
      for i in range(15)])

add(dirn='purchasing', slug='receipts-wh', menu='Purchasing', sub='Receipt(WH)',
    title='Receipt (WH)', desc='Warehouse Receipt Main · Penerimaan Gudang · 창고 입고 확정',
    listlabel='All Warehouse Receipts', ph='PO no, Supplier, Warehouse',
    new='NEW', segs=SEGS, chips=CHIPS,
    cols=[('#','#','ctr',None),('sup','SUPPLIER','ell',None),('no','RECEIPT NO.','code',None),
          ('rdt','RECEIPT DATE','date',None),('pono','PO NO.','code',None),
          ('arr','ACT. ARRIVAL','date',None),('qty','QTY','num','ASM.fmt.int'),
          ('st','STATUS','ctr','ASM.badge')],
    total=['qty'], totspan=3,
    rows=[(lambda n: dict(sup=n, no=f'RCW-2026{random.choice([7,8,9]):02d}-{300+i:03d}',
             rdt=d(-random.randint(0,45)), pono=pono(n,i), arr=d(-random.randint(0,45)),
             qty=random.choice([200,400,392,800,1200]),
             st=random.choice(['RECEIVED','PENDING','PARTIAL','COMPLETED'])))(sup())
      for i in range(14)])

add(dirn='purchasing', slug='import-cost', menu='Purchasing', sub='Import Cost',
    title='Import Cost', desc='Import Cost · Biaya Impor · 수입 부대비용 정산',
    listlabel='All Import Costs', ph='Supplier, PO no, Shipment no, Customs no',
    new=None, segs=SEGS,
    cols=[('#','#','ctr',None),('shp','SHIPMENT NO.','code',None),('rc','RECEIPT NO.','code',None),
          ('pono','PO NO.','code',None),('sup','SUPPLIER','ell',None),
          ('shq','SHIPMENT QTY','num','ASM.fmt.int'),('rcq','RECEIPT QTY','num','ASM.fmt.int'),
          ('ramt','RECEIPT AMOUNT','num','v=>ASM.fmt.cur("USD",v)'),
          ('camt','COST AMOUNT','num','v=>ASM.fmt.cur("IDR",v)'),
          ('cst','COST STATUS','ctr','ASM.badge'),('rst','RECEIPT STATUS','ctr','ASM.badge')],
    total=['shq','rcq','ramt','camt'], totspan=5,
    rows=[(lambda n,q: dict(shp=f'SHP-2026{random.choice([7,8]):02d}-{100+i:03d}',
             rc=f'RC-2026{random.choice([7,8]):02d}-{200+i:03d}', pono=pono(n,i), sup=n,
             shq=q, rcq=q, ramt=random.randint(60000,150000),
             camt=random.randint(48000000,210000000),
             cst=random.choice(['DRAFT','PENDING','COMPLETED','APPROVED']),
             rst=random.choice(['RECEIVED','COMPLETED','PARTIAL'])))(
         sup(True), random.choice([200,400,800,1200]))
      for i in range(13)])

add(dirn='purchasing', slug='vendor-return', menu='Purchasing', sub='Vendor Return',
    title='Vendor Return', desc='Vendor Return Main · Retur ke Pemasok · 공급사 반품',
    listlabel='All Vendor Returns', ph='Vendor return no, Supplier, Receipt no',
    new='NEW', segs=SEGS,
    cols=[('#','#','ctr',None),('no','RETURN NO.','code',None),('rdt','RETURN DATE','date',None),
          ('rc','RECEIPT NO.','code',None),('sup','SUPPLIER','ell',None),
          ('inv','SJL/INV NO.','code',None),('rcq','RECEIPT QTY','num','ASM.fmt.int'),
          ('rtq','RETURN QTY','num','ASM.fmt.int'),('wh','WAREHOUSE','ctr',None),
          ('st','STATUS','ctr','ASM.badge')],
    total=['rcq','rtq'], totspan=3,
    rows=[(lambda n,q: dict(no=f'VR-2026{random.choice([7,8,9]):02d}-{400+i:03d}',
             rdt=d(-random.randint(0,40)), rc=f'RC-2026{random.choice([7,8]):02d}-{200+i:03d}',
             sup=n, inv=f'INV/{random.randint(10000,99999)}/2026',
             rcq=q, rtq=random.choice([4,8,12,24]), wh=random.choice(WH),
             st=random.choice(['DRAFT','PENDING','APPROVED','COMPLETED','REJECTED'])))(
         sup(), random.choice([200,400,800]))
      for i in range(12)])

add(dirn='purchasing', slug='credit-note', menu='Purchasing', sub='Credit Note',
    title='Credit Note', desc='Credit Note Main · Nota Kredit · 반품 대금 정산',
    listlabel='All Credit Notes', ph='Return no, Credit note no, Supplier, Receipt no',
    new=None, segs=SEGS,
    cols=[('#','#','ctr',None),('no','CREDIT NOTE NO.','code',None),('cdt','C. NOTE DATE','date',None),
          ('rdt','RETURN DATE','date',None),('rc','RECEIPT NO.','code',None),
          ('sup','SUPPLIER','ell',None),('inv','SJL/INV NO.','code',None),
          ('rtq','RTN QTY','num','ASM.fmt.int'),
          ('amt','CREDIT AMOUNT','num','(v,r)=>ASM.fmt.cur(r.cur,v)'),
          ('wh','WAREHOUSE','ctr',None),('st','STATUS','ctr','ASM.badge')],
    total=['rtq'], totspan=4,
    rows=[(lambda n,im: dict(no=f'CN-2026{random.choice([7,8,9]):02d}-{500+i:03d}',
             cdt=d(-random.randint(0,35)), rdt=d(-random.randint(5,45)),
             rc=f'RC-2026{random.choice([7,8]):02d}-{200+i:03d}', sup=n,
             inv=f'INV/{random.randint(10000,99999)}/2026', rtq=random.choice([4,8,12,24]),
             amt=random.randint(1200,9800) if im else random.randint(9000000,68000000),
             cur='USD' if im else 'IDR', wh=random.choice(WH),
             st=random.choice(['DRAFT','PENDING','APPROVED','COMPLETED'])))(
         *(lambda im: (sup(im), im))(random.choice([True,False])))
      for i in range(12)])

# ══ PARTNERS ═══════════════════════════════════════════════════════════
add(dirn='partners', slug='customer', menu='Partners', sub='Customers',
    title='Customers', desc='Pelanggan · 고객사 마스터',
    listlabel='All Customers', ph='Customer name...', new='NEW',
    cols=[('#','#','ctr',None),('nm','CUSTOMER NAME','ell',None),('typ','TYPE','ctr',None),
          ('addr','ADDRESS','ell',None),('pic','PIC NAME','',None),('tel','PHONE NO.','code',None)],
    total=None, totspan=1,
    rows=[dict(nm=n, typ=t, addr=a, pic=p, tel=tel)
      for n,t,a,p,tel in [
        ('PT. TRANS MITRA SEJATI','DISTRIBUTOR','Pantai Indah Utara 2 Galeri Niaga, Mediterania II L, 8B, Kapuk Muara, Penjaringan, 14460','Stevie','021-5566-8821'),
        ('PT. BUKIT MAKMUR MANDIRI UTAMA','END USER','Jl. TB Simatupang No. 1, Cilandak, Jakarta Selatan, 12560','Bpk. Suryanto','021-2997-1000'),
        ('PT. PAMAPERSADA NUSANTARA','END USER','Jl. Rawa Gelam I No. 9, Kawasan Industri Pulogadung, Jakarta Timur','Bpk. Herman','021-4602-2000'),
        ('PT. KALTIM PRIMA COAL','END USER','Mine Site Sangatta, Kutai Timur, Kalimantan Timur, 75611','Bpk. Rahmat','0549-521-000'),
        ('PT. SAPTAINDRA SEJATI','END USER','TMT 2 Building, Jl. Cilandak KKO No. 1, Jakarta Selatan','Bpk. Dedi','021-2997-4000'),
        ('PT. THIESS CONTRACTORS INDONESIA','END USER','Ratu Prabu 2 Building, Jl. TB Simatupang Kav. 1B, Jakarta','Mr. Andrew','021-7883-1000'),
        ('CV. SUMBER BAN JAYA','DEALER','Jl. Raya Kaligawe KM 6 No. 88, Semarang, 50118','Bpk. Yanto','024-658-2211'),
        ('UD. MAKMUR TYRE','DEALER','Jl. Margomulyo Indah Blok C-12, Surabaya, 60186','Bpk. Anton','031-749-3300'),
        ('PT. PUTRA PERKASA ABADI','END USER','Jl. Kebon Sirih No. 39, Menteng, Jakarta Pusat','Bpk. Fajar','021-3193-8800'),
        ('PT. CIPTA KRIDATAMA','END USER','Jl. Mulawarman No. 12, Balikpapan, Kalimantan Timur','Bpk. Wawan','0542-771-200'),
        ('PT. ULIMA NITRA','END USER','Jl. Soekarno Hatta KM 12, Palembang, Sumatera Selatan','Bpk. Rudi','0711-411-800'),
        ('PT. BERAU COAL','END USER','Jl. Pemuda No. 40, Tanjung Redeb, Berau, Kalimantan Timur','Bpk. Iskandar','0554-233-00')]])

add(dirn='partners', slug='vendor', menu='Partners', sub='Suppliers',
    title='Suppliers', desc='Pemasok · 공급사 마스터',
    listlabel='All Suppliers', ph='Supplier name...', new='NEW',
    cols=[('#','#','ctr',None),('nm','SUPPLIER NAME','ell',None),('cty','COUNTRY','ctr',None),
          ('typ','TYPE','ctr',None),('addr','ADDRESS','ell',None),('tel','PHONE NO.','code',None)],
    total=None, totspan=1,
    rows=[dict(nm=n, cty=c, typ=t, addr=a, tel=tel)
      for n,c,t,a,tel in [
        ('HUA IN GLOBAL (SHANGHAI) CO., LTD','CHINA','IMPORT','Room 902, Block B Jingting Building, No.1000 Hong Quan Road, Minhang District, Shanghai, China','-'),
        ('HUBEI AULICE TYRE CO., LTD','CHINA','IMPORT','No. 1 Aulice Road, Zaoyang Industrial Park, Hubei, China','+86-710-6259-888'),
        ('DONGYING RUNGOLD TYRE CO., LTD','CHINA','IMPORT','Guangrao Economic Development Zone, Dongying, Shandong, China','+86-546-763-8888'),
        ('TECHKING TIRES LIMITED','CHINA','IMPORT','No. 1 Fuqian Road, Qingdao, Shandong, China','+86-532-8099-6688'),
        ('CAMSO LOADSTAR (PVT) LTD','SRI LANKA','IMPORT','Ekala, Ja-Ela, Gampaha District, Sri Lanka','+94-11-223-6000'),
        ('PT. DIAMOND FAJAR JAYA','INDONESIA','LOCAL','Jl. Raya Serang KM 18, Cikupa, Tangerang, Banten','021-5960-1200'),
        ('PT. ARAMI JAYA','INDONESIA','LOCAL','Jl. Raya Industri No. 22, Cikarang, Bekasi, Jawa Barat','021-8983-4400'),
        ('PT. MULTISTRADA ARAH SARANA','INDONESIA','LOCAL','Jl. Raya Lemahabang KM 58.3, Cikarang Timur, Bekasi','021-8983-1234'),
        ('PT. SAMUDERA INDONESIA (FORWARDER)','INDONESIA','LOCAL','Jl. Letjen S. Parman Kav. 35, Jakarta Barat','021-548-0800'),
        ('PT. AGILITY INTERNATIONAL','INDONESIA','LOCAL','Soewarna Business Park Block E, Soekarno-Hatta Airport','021-559-1000')]])

# ── HTML 생성 ──────────────────────────────────────────────────────────
def js_cols(cols):
    out = []
    for k, lab, cls, f in cols:
        s = '{key:%s,label:%s' % (json.dumps(k), json.dumps(lab))
        if cls: s += ',cls:%s' % json.dumps(cls)
        if f:   s += ',fmt:' + f
        out.append(s + '}')
    return ',\n      '.join(out)

PAGE = '''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="PT ASCENDO INTERNASIONAL">
<title>{title} · ASM</title>
<link rel="stylesheet" href="../assets/asm-common.css">
</head>
<body data-menu="{menu}" data-sub="{sub}">

<main class="asm-main">

  <div class="mock-flag">
    시안(Mock-up)입니다 — 실제 ASM 데이터가 아니며 표시된 수치는 모두 예시입니다.
    디자인 기준 : ASM 디자인가이드 v1.0 (삼탄 TMS). 배포 시 이 줄과 <code>.mock-flag</code> 를 삭제하십시오.
  </div>

  <div class="page-head">
    <div>
      <h1>{title}</h1>
      <div class="desc">{desc}</div>
    </div>
    <div class="right">
      <button class="btn btn-outline" onclick="window.print()">Print</button>
      <button class="btn btn-outline" data-csv>Excel</button>
      {newbtn}
    </div>
  </div>

  <!-- 검색 바 -->
  <div class="search-bar">
    <span class="sb-label">Search</span>
{searchctl}    <input class="form-control" type="search" data-search placeholder="{ph}">
{chips}    <button class="btn btn-primary" data-search-btn>SEARCH</button>
    <button class="btn btn-outline" data-reset>RESET</button>
  </div>

  <!-- 목록 -->
  <div class="card">
    <div class="card-head">
      <h2>{listlabel}</h2>
      <span class="count-badge" data-count>0</span>
      <span class="spacer"></span>
      <span class="meta" data-pageinfo>Page 1 of 1</span>
    </div>
    <div id="grid"></div>
  </div>

</main>

<script src="../assets/asm-common.js"></script>
<script>
/* 이 화면의 데이터 — 실서비스 연결 시 fetch('/api/{slug}') 결과로 교체하십시오. */
const ROWS = {rows};

ASM.grid({{
  mount   : '#grid',
  pageSize: 15,
  columns : [
      {cols}
  ],{total}
  rows    : ROWS
}});
</script>
</body>
</html>
'''

INDEX_ROWS = []
for s in SCREENS:
    # 검색 유형 : 실제 ASM 이 Keyword/Date 세그먼트인 화면은 segs 지정, 그 외는 컬럼 셀렉트
    if s.get('segs'):
        searchctl = '    <div class="seg">' + ''.join(
            '<button class="%s" type="button">%s</button>' % ('on' if i == 0 else '', g)
            for i, g in enumerate(s['segs'])) + '</div>\n'
    else:
        opts = ''.join('<option>%s</option>' % lab for k, lab, c, f in s['cols'] if k != '#')
        searchctl = ('    <select class="form-select"><option>Keyword</option>%s</select>\n' % opts)
    chips = ('    <div class="chips">' + ''.join(
        '<button class="%s" type="button">%s</button>' % ('on' if i == 0 else '', ch)
        for i, ch in enumerate(s['chips'])) + '</div>\n') if s.get('chips') else ''
    newbtn = ('<button class="btn btn-primary">＋ %s</button>' % s['new']) if s['new'] else ''
    total = ('\n  total   : %s,\n  totalLabelSpan : %d,' % (json.dumps(s['total']), s['totspan'])) if s['total'] else ''
    html = PAGE.format(title=s['title'], menu=s['menu'], sub=s['sub'], desc=s['desc'],
                       ph=s['ph'], searchctl=searchctl, chips=chips, newbtn=newbtn, slug=s['slug'],
                       listlabel=s.get('listlabel') or (s['title'] + ' List'),
                       rows=json.dumps(s['rows'], ensure_ascii=False, indent=0).replace('\n', ''),
                       cols=js_cols(s['cols']), total=total)
    path = os.path.join(ROOT, s['dirn'], s['slug'] + '.html')
    open(path, 'w', encoding='utf-8').write(html)
    INDEX_ROWS.append((s['menu'], s['sub'], s['dirn'] + '/' + s['slug'] + '.html', s['desc'], len(s['rows'])))

print('generated', len(SCREENS), 'screens')

# ── index.html ────────────────────────────────────────────────────────
groups = {}
for menu, sub, path, desc, n in INDEX_ROWS:
    groups.setdefault(menu, []).append((sub, path, desc, n))
cards = []
for menu, items in groups.items():
    lis = ''.join(
        '      <a class="scr" href="%s">\n        <b>%s</b>\n'
        '        <span class="d">%s</span>\n        <span class="n">%d rows</span>\n      </a>\n'
        % (p, sub, desc, n) for sub, p, desc, n in items)
    cards.append('  <div class="card">\n'
        '    <div class="card-head"><h2>%s</h2><span class="count-badge">%d</span></div>\n'
        '    <div class="card-body">\n      <div class="scr-grid">\n%s      </div>\n    </div>\n  </div>\n'
        % (menu, len(items), lis))

IDX = open(os.path.join(ROOT, '_index_tpl.html'), encoding='utf-8').read()
open(os.path.join(ROOT, 'index.html'), 'w', encoding='utf-8').write(
    IDX.replace('{{CARDS}}', ''.join(cards)).replace('{{N}}', str(len(INDEX_ROWS))))
print('index.html rebuilt')
